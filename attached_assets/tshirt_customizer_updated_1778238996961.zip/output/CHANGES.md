# 3D T-Shirt Customizer — Updated Files

## What Changed

### App.jsx (major rewrite)
- Replaced the old 2-column pattern/color layout with the **4-step wizard** from the wireframe:
  - **Step 1 – Style**: Solid / Print / Pattern tabs + sleeve length toggle
  - **Step 2 – Parts**: Per-part color override for Collar, Front, Back, Sleeves
  - **Step 3 – Logo**: Upload + 9-position grid + size slider
  - **Step 4 – Size**: Standard size buttons + size chart + custom measurements
- Step nav bar with done ✓ indicators
- Live summary badges in the preview panel update in real-time

### TShirtViewer.jsx (major rewrite)
- **Per-part coloring via canvas UV texture** — builds a 2048×2048 canvas that
  approximates the polo shirt UV zones (collar strip, sleeve bands, front body, back body)
  and applies it as a `THREE.CanvasTexture`
- **Logo overlay** — draws the uploaded image onto the front UV region at the
  selected position and scaled by the logoSize slider
- **Half-sleeve masking** — paints over the lower sleeve UV region when "Half sleeve" is selected
- **OrbitControls** for proper drag-to-rotate + scroll-to-zoom + damping
- Auto-rotate on load; stops when user interacts
- Proper auto-centering & scaling via `Box3` so any model fits the viewport
- Shadow ground plane, three-point lighting (key, fill, rim)
- `flipY = false` on the canvas texture (required for GLB UV coordinates)

### App.css (full redesign)
- New design system: warm neutral palette (`#F7F6F3` bg, clean whites)
- DM Sans + DM Mono typography
- All wireframe components styled: steps, tabs, swatches, print grid, parts list,
  upload zone, position grid, slider, size buttons, size chart, custom fields
- Sticky preview panel on desktop; collapses above wizard on mobile (<900px)

## Integration Notes

1. Place `collar_t-shirt_model.glb` in your **`/public/`** folder (Vite) or
   `public/` (Create React App). The model is fetched at `/collar_t-shirt_model.glb`.

2. Install OrbitControls — included in `three/examples/jsm/controls/OrbitControls.js`.
   No extra package needed if you already have `three` installed.

3. File structure expected by the updated code:
   ```
   src/
     App.jsx
     App.css
     components/
       TShirtViewer.jsx
     data/
       patterns.js
   public/
     collar_t-shirt_model.glb
   ```

4. The old `PatternSelector.jsx` and `ColorCustomizer.jsx` components are no longer
   imported by `App.jsx` — their functionality is now inline in the step panels.
   You can delete them or keep for reference.

## UV Texture Zones (approximate)
The canvas texture is divided into regions that match typical polo shirt UV layouts:
```
┌──────────────────────────────────────────────────┐
│                  COLLAR  (top 8%)                │
├────────────┬──────────────────────┬──────────────┤
│ LEFT       │                      │ RIGHT        │
│ SLEEVE     │    FRONT BODY        │ SLEEVE       │
│ (18%)      │    (64%)             │ (18%)        │
├────────────┴──────────────────────┴──────────────┤
│                  BACK BODY  (40%)                │
└──────────────────────────────────────────────────┘
```
If the model's UV layout differs, adjust the zone percentages in `buildShirtTexture()`
inside `TShirtViewer.jsx`.
