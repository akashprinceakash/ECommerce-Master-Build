import React, { useEffect, useRef, useState, useCallback } from 'react'
import * as THREE from 'three'
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js'
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js'

// Canvas size for UV texture
const TEX_W = 2048
const TEX_H = 2048

// Logo position mapping → UV canvas coordinates (approx front-face region)
// Front face in a typical polo UV is roughly centered: x 30-70%, y 15-60%
const FRONT_UV = { x: 0.30, y: 0.15, w: 0.40, h: 0.45 }

const LOGO_POS_MAP = {
  'top-left':    { rx: 0.05, ry: 0.05 },
  'top-center':  { rx: 0.30, ry: 0.05 },
  'top-right':   { rx: 0.55, ry: 0.05 },
  'mid-left':    { rx: 0.05, ry: 0.30 },
  'center':      { rx: 0.30, ry: 0.30 },
  'mid-right':   { rx: 0.55, ry: 0.30 },
  'bot-left':    { rx: 0.05, ry: 0.60 },
  'bot-center':  { rx: 0.30, ry: 0.60 },
  'bot-right':   { rx: 0.55, ry: 0.60 },
}

/**
 * Build a canvas UV texture that approximates shirt-part coloring.
 *
 * Typical polo-shirt UV layout (equirectangular unwrap):
 *   ┌────────────────────────────────────────────────────┐
 *   │                    COLLAR (top strip)              │ ~5%
 *   ├──────────┬─────────────────────────┬──────────────-┤
 *   │  LEFT    │         FRONT           │   RIGHT       │
 *   │  SLEEVE  │         BODY            │   SLEEVE      │ ~55%
 *   ├──────────┴─────────────────────────┴──────────────-┤
 *   │                    BACK BODY                       │ ~40%
 *   └────────────────────────────────────────────────────┘
 *
 * These are approximations—exact regions vary per model.
 */
function buildShirtTexture(partColors, logoImg, logoPosition, logoSize, sleeveType) {
  const canvas = document.createElement('canvas')
  canvas.width = TEX_W
  canvas.height = TEX_H
  const ctx = canvas.getContext('2d')

  const W = TEX_W
  const H = TEX_H

  // ── Approximate UV zones ──────────────────────────────────────────────────
  const COLLAR_H   = Math.floor(H * 0.08)
  const BODY_H     = Math.floor(H * 0.52)
  const BACK_Y     = COLLAR_H + BODY_H
  const BACK_H     = H - BACK_Y

  const SLEEVE_W   = Math.floor(W * 0.18)
  const FRONT_X    = SLEEVE_W
  const FRONT_W    = W - SLEEVE_W * 2

  // 1. Fill entire canvas with front color as base (catches unmapped areas)
  ctx.fillStyle = partColors.front.hex
  ctx.fillRect(0, 0, W, H)

  // 2. Collar
  ctx.fillStyle = partColors.collar.hex
  ctx.fillRect(0, 0, W, COLLAR_H)

  // 3. Left sleeve
  ctx.fillStyle = partColors.sleeves.hex
  ctx.fillRect(0, COLLAR_H, SLEEVE_W, BODY_H)

  // 4. Right sleeve
  ctx.fillStyle = partColors.sleeves.hex
  ctx.fillRect(W - SLEEVE_W, COLLAR_H, SLEEVE_W, BODY_H)

  // 5. Back body
  ctx.fillStyle = partColors.back.hex
  ctx.fillRect(0, BACK_Y, W, BACK_H)

  // 6. Soft seam lines to add depth (subtle 2px dividers)
  ctx.globalAlpha = 0.12
  ctx.strokeStyle = '#000'
  ctx.lineWidth = 4
  // collar bottom
  ctx.beginPath(); ctx.moveTo(0, COLLAR_H); ctx.lineTo(W, COLLAR_H); ctx.stroke()
  // sleeve dividers
  ctx.beginPath(); ctx.moveTo(SLEEVE_W, COLLAR_H); ctx.lineTo(SLEEVE_W, COLLAR_H + BODY_H); ctx.stroke()
  ctx.beginPath(); ctx.moveTo(W - SLEEVE_W, COLLAR_H); ctx.lineTo(W - SLEEVE_W, COLLAR_H + BODY_H); ctx.stroke()
  // front/back divider
  ctx.beginPath(); ctx.moveTo(0, BACK_Y); ctx.lineTo(W, BACK_Y); ctx.stroke()
  ctx.globalAlpha = 1

  // 7. Half-sleeve mask – paint over lower sleeve with front/back colors
  if (sleeveType === 'half') {
    const maskY = COLLAR_H + Math.floor(BODY_H * 0.45)
    const maskH = Math.floor(BODY_H * 0.55)
    ctx.fillStyle = partColors.front.hex
    ctx.fillRect(0, maskY, SLEEVE_W, maskH)
    ctx.fillRect(W - SLEEVE_W, maskY, SLEEVE_W, maskH)
    // subtle edge line
    ctx.globalAlpha = 0.15
    ctx.strokeStyle = '#000'
    ctx.lineWidth = 3
    ctx.beginPath(); ctx.moveTo(0, maskY); ctx.lineTo(SLEEVE_W, maskY); ctx.stroke()
    ctx.beginPath(); ctx.moveTo(W - SLEEVE_W, maskY); ctx.lineTo(W, maskY); ctx.stroke()
    ctx.globalAlpha = 1
  }

  // 8. Logo overlay on front body region
  if (logoImg) {
    const pos = LOGO_POS_MAP[logoPosition] || LOGO_POS_MAP['top-center']
    const frontAreaX = FRONT_X
    const frontAreaY = COLLAR_H
    const frontAreaW = FRONT_W
    const frontAreaH = BODY_H

    const maxLogoW = frontAreaW * (logoSize / 100) * 0.7
    const maxLogoH = frontAreaH * (logoSize / 100) * 0.5

    const ratio = logoImg.naturalWidth / logoImg.naturalHeight
    let logoW, logoH
    if (ratio > 1) {
      logoW = maxLogoW
      logoH = logoW / ratio
    } else {
      logoH = maxLogoH
      logoW = logoH * ratio
    }

    const logoX = frontAreaX + pos.rx * frontAreaW
    const logoY = frontAreaY + pos.ry * frontAreaH

    ctx.drawImage(logoImg, logoX, logoY, logoW, logoH)
  }

  return canvas
}

const TShirtViewer = ({ partColors, sleeveType, logoData, logoPosition, logoSize }) => {
  const containerRef = useRef(null)
  const rendererRef = useRef(null)
  const sceneRef = useRef(null)
  const cameraRef = useRef(null)
  const controlsRef = useRef(null)
  const shirtMeshRef = useRef(null)
  const textureRef = useRef(null)
  const animFrameRef = useRef(null)
  const logoImgRef = useRef(null)
  const [isLoading, setIsLoading] = useState(true)
  const [loadError, setLoadError] = useState(null)

  // Load logo image into a cached HTMLImageElement
  useEffect(() => {
    if (!logoData) {
      logoImgRef.current = null
      return
    }
    const img = new Image()
    img.onload = () => { logoImgRef.current = img }
    img.src = logoData
  }, [logoData])

  const rebuildTexture = useCallback(() => {
    if (!shirtMeshRef.current || !partColors) return

    const canvas = buildShirtTexture(
      partColors,
      logoImgRef.current,
      logoPosition,
      logoSize,
      sleeveType
    )

    if (textureRef.current) textureRef.current.dispose()
    const tex = new THREE.CanvasTexture(canvas)
    tex.flipY = false  // GLB textures often need flipY = false
    tex.needsUpdate = true
    textureRef.current = tex

    shirtMeshRef.current.traverse(child => {
      if (child.isMesh && child.material) {
        const mat = child.material
        // Only apply to polo shirt material, not buttons
        if (child.material.name !== 'Button') {
          mat.map = tex
          mat.color.set(0xffffff) // reset tint so canvas colors show correctly
          mat.needsUpdate = true
        }
      }
    })
  }, [partColors, logoPosition, logoSize, sleeveType])

  // Re-render texture when colors/logo/sleeve change
  useEffect(() => {
    rebuildTexture()
  }, [rebuildTexture])

  // Also rebuild when logo image loads
  useEffect(() => {
    if (!logoData) return
    // slight delay to let the image load
    const tid = setTimeout(() => rebuildTexture(), 300)
    return () => clearTimeout(tid)
  }, [logoData, rebuildTexture])

  // Initialize Three.js scene once
  useEffect(() => {
    if (!containerRef.current) return

    // Scene
    const scene = new THREE.Scene()
    scene.background = new THREE.Color(0xf4f4f4)
    sceneRef.current = scene

    // Camera
    const w = containerRef.current.clientWidth
    const h = containerRef.current.clientHeight || 480
    const camera = new THREE.PerspectiveCamera(45, w / h, 0.01, 100)
    camera.position.set(0, 0.1, 2.4)
    cameraRef.current = camera

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false })
    renderer.setSize(w, h)
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
    renderer.shadowMap.enabled = true
    renderer.shadowMap.type = THREE.PCFSoftShadowMap
    renderer.outputColorSpace = THREE.SRGBColorSpace
    containerRef.current.appendChild(renderer.domElement)
    rendererRef.current = renderer

    // Orbit Controls
    const controls = new OrbitControls(camera, renderer.domElement)
    controls.enableDamping = true
    controls.dampingFactor = 0.08
    controls.minDistance = 0.8
    controls.maxDistance = 5
    controls.maxPolarAngle = Math.PI * 0.85
    controls.target.set(0, 0, 0)
    controlsRef.current = controls

    // Lighting
    const ambient = new THREE.AmbientLight(0xffffff, 1.2)
    scene.add(ambient)

    const key = new THREE.DirectionalLight(0xfff5e8, 2.0)
    key.position.set(3, 5, 4)
    key.castShadow = true
    scene.add(key)

    const fill = new THREE.DirectionalLight(0xe8f0ff, 0.8)
    fill.position.set(-3, 2, -2)
    scene.add(fill)

    const rim = new THREE.DirectionalLight(0xffffff, 0.5)
    rim.position.set(0, -3, -3)
    scene.add(rim)

    // Ground plane for shadow
    const groundGeo = new THREE.PlaneGeometry(10, 10)
    const groundMat = new THREE.ShadowMaterial({ opacity: 0.12 })
    const ground = new THREE.Mesh(groundGeo, groundMat)
    ground.rotation.x = -Math.PI / 2
    ground.position.y = -0.85
    ground.receiveShadow = true
    scene.add(ground)

    // Load GLB model
    const loader = new GLTFLoader()
    loader.load(
      '/collar_t-shirt_model.glb',
      (gltf) => {
        const model = gltf.scene

        // Auto-center and scale
        const box = new THREE.Box3().setFromObject(model)
        const center = box.getCenter(new THREE.Vector3())
        const size = box.getSize(new THREE.Vector3())
        const maxDim = Math.max(size.x, size.y, size.z)
        const scale = 1.6 / maxDim
        model.scale.setScalar(scale)
        model.position.sub(center.multiplyScalar(scale))

        model.traverse(child => {
          if (child.isMesh) {
            child.castShadow = true
            child.receiveShadow = true
          }
        })

        scene.add(model)
        shirtMeshRef.current = model
        setIsLoading(false)

        // Apply initial texture
        const canvas = buildShirtTexture(
          partColors || {
            collar: { hex: '#1a1a1a', name: 'Black' },
            front: { hex: '#1a1a1a', name: 'Black' },
            back: { hex: '#1a1a1a', name: 'Black' },
            sleeves: { hex: '#1a1a1a', name: 'Black' },
          },
          null,
          logoPosition || 'top-center',
          logoSize || 50,
          sleeveType || 'half'
        )
        const tex = new THREE.CanvasTexture(canvas)
        tex.flipY = false
        tex.needsUpdate = true
        textureRef.current = tex

        model.traverse(child => {
          if (child.isMesh && child.material && child.material.name !== 'Button') {
            child.material.map = tex
            child.material.color.set(0xffffff)
            child.material.needsUpdate = true
          }
        })
      },
      undefined,
      (error) => {
        console.error('Error loading model:', error)
        setLoadError('Failed to load 3D model')
        setIsLoading(false)
      }
    )

    // Render loop
    let autoRotate = true
    renderer.domElement.addEventListener('pointerdown', () => { autoRotate = false })

    const animate = () => {
      animFrameRef.current = requestAnimationFrame(animate)
      controls.update()
      if (autoRotate && shirtMeshRef.current) {
        shirtMeshRef.current.rotation.y += 0.004
      }
      renderer.render(scene, camera)
    }
    animate()

    // Resize
    const onResize = () => {
      if (!containerRef.current) return
      const w2 = containerRef.current.clientWidth
      const h2 = containerRef.current.clientHeight || 480
      camera.aspect = w2 / h2
      camera.updateProjectionMatrix()
      renderer.setSize(w2, h2)
    }
    window.addEventListener('resize', onResize)

    return () => {
      window.removeEventListener('resize', onResize)
      cancelAnimationFrame(animFrameRef.current)
      controls.dispose()
      renderer.dispose()
      if (textureRef.current) textureRef.current.dispose()
      if (containerRef.current && renderer.domElement.parentNode === containerRef.current) {
        containerRef.current.removeChild(renderer.domElement)
      }
    }
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div style={{ position: 'relative', width: '100%', height: '420px', borderRadius: '8px', overflow: 'hidden', background: '#f4f4f4' }}>
      <div ref={containerRef} style={{ width: '100%', height: '100%' }} />
      {isLoading && (
        <div className="viewer-overlay">
          <div className="loader-ring" />
          <span>Loading 3D model…</span>
        </div>
      )}
      {loadError && (
        <div className="viewer-overlay">
          <span style={{ color: '#e24b4a' }}>⚠ {loadError}</span>
        </div>
      )}
    </div>
  )
}

export default TShirtViewer
