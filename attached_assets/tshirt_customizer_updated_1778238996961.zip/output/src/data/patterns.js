// Color palette
export const colorPalette = {
  'C5D3DE': '#C5D3DE',
  'F8F4E9': '#F8F4E9',
  'ACB1A1': '#ACB1A1',
  'F0CED2': '#F0CED2',
  'E9DAC3': '#E9DAC3',
  'FFFFFF': '#FFFFFF',
  '585858': '#585858',
  '576043': '#576043',
  'DA1F26': '#DA1F26',
  '273878': '#273878',
  '243C2F': '#243C2F',
  '362223': '#362223',
  '000000': '#000000',
}

export const patterns = [
  { id: 'GT001', name: 'Classic Polo', type: 'solid', description: 'Solid color with contrasting collar and cuffs', colors: ['C5D3DE', '362223'], colorNames: ['Primary', 'Accent'] },
  { id: 'GT002', name: 'Pink Polo', type: 'solid', description: 'Solid color with contrasting collar and cuffs', colors: ['F0CED2', '362223'], colorNames: ['Primary', 'Accent'] },
  { id: 'GT003', name: 'Sage Polo', type: 'solid', description: 'Solid color with contrasting collar and cuffs', colors: ['ACB1A1', '362223'], colorNames: ['Primary', 'Accent'] },
  { id: 'GT004', name: 'Beige Polo', type: 'solid', description: 'Solid color with contrasting collar and cuffs', colors: ['E9DAC3', '362223'], colorNames: ['Primary', 'Accent'] },
  { id: 'GT005', name: 'Navy Colorblock', type: 'colorblock', description: 'Navy with white collar and cuffs', colors: ['273878', 'FFFFFF'], colorNames: ['Primary', 'Accent'] },
  { id: 'GT006', name: 'Green Panels', type: 'panel', description: 'Green body with black side panels', colors: ['576043', '000000'], colorNames: ['Primary', 'Panels'] },
  { id: 'GT007', name: 'Red Panels', type: 'panel', description: 'Red body with black side panels', colors: ['DA1F26', '000000'], colorNames: ['Primary', 'Panels'] },
  { id: 'GT014', name: 'Blue Curve', type: 'colorblock', description: 'Light blue with cream curved panels', colors: ['C5D3DE', 'F8F4E9'], colorNames: ['Primary', 'Panels'] },
  { id: 'GT015', name: 'Pink Curve', type: 'colorblock', description: 'Pink with black curved panels', colors: ['F0CED2', '000000'], colorNames: ['Primary', 'Panels'] },
]

export const getPatternById = (id) => patterns.find(p => p.id === id)
export const getColorHex = (colorKey) => colorPalette[colorKey] || '#000000'
