import { useState, useCallback } from 'react'
import TShirtViewer from './components/TShirtViewer'
import { colorPalette } from './data/patterns'
import './App.css'

const COLORS = [
  { hex: '#1a1a1a', name: 'Black' },
  { hex: '#FFFFFF', name: 'White' },
  { hex: '#e8e0d8', name: 'Cream' },
  { hex: '#d4c5a9', name: 'Sand' },
  { hex: '#C5D3DE', name: 'Sky' },
  { hex: '#378ADD', name: 'Blue' },
  { hex: '#185FA5', name: 'Navy' },
  { hex: '#273878', name: 'Indigo' },
  { hex: '#4a7c59', name: 'Forest' },
  { hex: '#576043', name: 'Olive' },
  { hex: '#97C459', name: 'Lime' },
  { hex: '#E24B4A', name: 'Red' },
  { hex: '#DA1F26', name: 'Crimson' },
  { hex: '#D85A30', name: 'Orange' },
  { hex: '#D4537E', name: 'Pink' },
  { hex: '#F0CED2', name: 'Blush' },
  { hex: '#7F77DD', name: 'Purple' },
  { hex: '#BA7517', name: 'Amber' },
  { hex: '#888780', name: 'Grey' },
  { hex: '#585858', name: 'Slate' },
]

const SIZES = ['XS', 'S', 'M', 'L', 'XL', 'XXL']

const PRINTS = [
  { id: 'floral', name: 'Floral', bg: 'repeating-linear-gradient(45deg,#f5e6d3,#f5e6d3 4px,#e8c9a0 4px,#e8c9a0 8px)' },
  { id: 'abstract', name: 'Abstract', bg: 'repeating-radial-gradient(circle,#d4e8f5,#d4e8f5 3px,#a8d0ee 3px,#a8d0ee 6px)' },
  { id: 'geo', name: 'Geo', bg: 'repeating-linear-gradient(90deg,#c8d8e8,#c8d8e8 8px,#8aaec8 8px,#8aaec8 9px)' },
  { id: 'camo', name: 'Camo', bg: 'repeating-conic-gradient(#7a8c5a 0% 25%,#5c6e40 0% 50%)' },
  { id: 'digital', name: 'Digital', bg: 'repeating-linear-gradient(0deg,#1a1a2e,#1a1a2e 5px,#16213e 5px,#16213e 10px)' },
  { id: 'stripes', name: 'Stripes', bg: 'repeating-linear-gradient(0deg,#1a1a1a,#1a1a1a 4px,#fff 4px,#fff 12px)' },
  { id: 'diagonal', name: 'Diagonal', bg: 'repeating-linear-gradient(45deg,#1a1a1a,#1a1a1a 2px,#fff 2px,#fff 10px)' },
  { id: 'houndstooth', name: 'Htooth', bg: 'repeating-linear-gradient(45deg,transparent,transparent 5px,#ccc 5px,#ccc 6px),repeating-linear-gradient(-45deg,transparent,transparent 5px,#ccc 5px,#ccc 6px)' },
]

const POSITIONS = [
  { id: 'top-left', icon: '↖' }, { id: 'top-center', icon: '↑' }, { id: 'top-right', icon: '↗' },
  { id: 'mid-left', icon: '←' }, { id: 'center', icon: '◉' }, { id: 'mid-right', icon: '→' },
  { id: 'bot-left', icon: '↙' }, { id: 'bot-center', icon: '↓' }, { id: 'bot-right', icon: '↘' },
]

function SwatchGrid({ colors, selected, onSelect, cols = 8 }) {
  return (
    <div className="swatch-grid" style={{ gridTemplateColumns: `repeat(${cols}, 1fr)` }}>
      {colors.map(c => (
        <button
          key={c.hex}
          className={`swatch${selected === c.hex ? ' selected' : ''}`}
          style={{ background: c.hex, border: c.hex === '#FFFFFF' ? '0.5px solid #ddd' : undefined }}
          title={c.name}
          onClick={() => onSelect(c)}
        />
      ))}
    </div>
  )
}

function StepNav({ current, onGo }) {
  const steps = [{ n: 1, label: 'Style' }, { n: 2, label: 'Parts' }, { n: 3, label: 'Logo' }, { n: 4, label: 'Size' }]
  return (
    <div className="steps">
      {steps.map((s, i) => (
        <div key={s.n} style={{ display: 'flex', alignItems: 'center', flex: i < steps.length - 1 ? '1' : undefined }}>
          <button
            className={`step${current === s.n ? ' active' : current > s.n ? ' done' : ''}`}
            onClick={() => onGo(s.n)}
          >
            <span className="step-num">{current > s.n ? '✓' : s.n}</span>
            <span>{s.label}</span>
          </button>
          {i < steps.length - 1 && <div className="step-div" />}
        </div>
      ))}
    </div>
  )
}

export default function App() {
  const [step, setStep] = useState(1)

  // Step 1 – Style
  const [styleTab, setStyleTab] = useState('solid')
  const [mainColor, setMainColor] = useState(COLORS[0])
  const [selectedPrint, setSelectedPrint] = useState(null)
  const [sleeveType, setSleeveType] = useState('half')

  // Step 2 – Parts
  const [activePart, setActivePart] = useState('collar')
  const [partColors, setPartColors] = useState({
    collar: { hex: '#1a1a1a', name: 'Black' },
    front: { hex: '#1a1a1a', name: 'Black' },
    back: { hex: '#1a1a1a', name: 'Black' },
    sleeves: { hex: '#1a1a1a', name: 'Black' },
  })

  // Step 3 – Logo
  const [logoData, setLogoData] = useState(null)
  const [logoPosition, setLogoPosition] = useState('top-center')
  const [logoSize, setLogoSize] = useState(50)

  // Step 4 – Size
  const [size, setSize] = useState('S')
  const [showChart, setShowChart] = useState(false)
  const [customEnabled, setCustomEnabled] = useState(false)

  const applyMainToAll = (color) => {
    setMainColor(color)
    setPartColors({ collar: color, front: color, back: color, sleeves: color })
  }

  const handlePartColor = (color) => {
    setPartColors(prev => ({ ...prev, [activePart]: color }))
  }

  const applyAllFromActive = () => {
    const col = partColors[activePart]
    setPartColors({ collar: col, front: col, back: col, sleeves: col })
  }

  const handleLogoUpload = useCallback((e) => {
    const file = e.target.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = (ev) => setLogoData(ev.target.result)
    reader.readAsDataURL(file)
  }, [])

  const PART_LIST = [
    { key: 'collar', label: 'Collar' },
    { key: 'front', label: 'Front' },
    { key: 'back', label: 'Back' },
    { key: 'sleeves', label: 'Sleeves' },
  ]

  const summaryStyle = styleTab === 'solid'
    ? `Solid · ${mainColor.name}`
    : styleTab === 'print'
    ? `Print · ${selectedPrint?.name || '—'}`
    : `Pattern`

  return (
    <div className="app-root">
      <header className="app-header">
        <div className="header-inner">
          <div className="brand">
            <span className="brand-icon">◈</span>
            <span className="brand-name">StitchCraft</span>
            <span className="brand-tag">3D Customizer</span>
          </div>
          <nav className="header-nav">
            <button className="nav-link active">Design</button>
            <button className="nav-link">Orders</button>
            <button className="nav-link">Gallery</button>
          </nav>
        </div>
      </header>

      <main className="app-main">
        {/* Left – Wizard */}
        <div className="wizard-col">
          <StepNav current={step} onGo={setStep} />

          {/* ─── STEP 1: STYLE ─── */}
          {step === 1 && (
            <div className="panel">
              <div className="panel-title">Choose base style</div>
              <div className="tab-row">
                {['solid', 'print', 'pattern'].map(t => (
                  <button key={t} className={`tab${styleTab === t ? ' active' : ''}`} onClick={() => setStyleTab(t)}>
                    {t.charAt(0).toUpperCase() + t.slice(1)}s
                  </button>
                ))}
              </div>

              {styleTab === 'solid' && (
                <>
                  <div className="section-title">Pick a colour</div>
                  <SwatchGrid colors={COLORS} selected={mainColor.hex} onSelect={applyMainToAll} />
                  <p className="note">ℹ You can override individual parts in Step 2</p>
                </>
              )}

              {styleTab === 'print' && (
                <>
                  <div className="section-title">Print library</div>
                  <div className="print-grid">
                    {PRINTS.map(p => (
                      <button
                        key={p.id}
                        className={`print-thumb${selectedPrint?.id === p.id ? ' selected' : ''}`}
                        style={{ background: p.bg }}
                        onClick={() => setSelectedPrint(p)}
                      >
                        <span>{p.name}</span>
                      </button>
                    ))}
                  </div>
                </>
              )}

              {styleTab === 'pattern' && (
                <>
                  <div className="section-title">Pattern type</div>
                  <div className="print-grid">
                    {[
                      { id: 'stripes', name: 'Stripes', bg: 'repeating-linear-gradient(0deg,#1a1a1a,#1a1a1a 4px,#fff 4px,#fff 12px)' },
                      { id: 'diagonal', name: 'Diagonal', bg: 'repeating-linear-gradient(45deg,#1a1a1a,#1a1a1a 2px,#fff 2px,#fff 10px)' },
                      { id: 'grid', name: 'Grid', bg: 'repeating-linear-gradient(0deg,transparent,transparent 8px,#ccc 8px,#ccc 9px),repeating-linear-gradient(90deg,transparent,transparent 8px,#ccc 8px,#ccc 9px)' },
                      { id: 'htooth', name: 'Houndstooth', bg: 'repeating-linear-gradient(45deg,transparent,transparent 5px,#ccc 5px,#ccc 6px),repeating-linear-gradient(-45deg,transparent,transparent 5px,#ccc 5px,#ccc 6px)' },
                    ].map(p => (
                      <button key={p.id} className={`print-thumb${selectedPrint?.id === p.id ? ' selected' : ''}`} style={{ background: p.bg }} onClick={() => setSelectedPrint(p)}>
                        <span>{p.name}</span>
                      </button>
                    ))}
                  </div>
                  <div className="section-title" style={{ marginTop: '1rem' }}>Pattern colours</div>
                  <div className="two-col-swatches">
                    <div>
                      <div className="micro-label">Colour A</div>
                      <SwatchGrid colors={COLORS.slice(0, 6)} selected={mainColor.hex} onSelect={applyMainToAll} cols={6} />
                    </div>
                    <div>
                      <div className="micro-label">Colour B</div>
                      <SwatchGrid colors={COLORS.slice(6, 12)} selected={partColors.collar.hex} onSelect={c => setPartColors(p => ({ ...p, collar: c }))} cols={6} />
                    </div>
                  </div>
                </>
              )}

              <hr className="divider" />
              <div className="section-title">Sleeve length</div>
              <div className="toggle-row">
                {['half', 'full'].map(s => (
                  <button key={s} className={`toggle-btn${sleeveType === s ? ' active' : ''}`} onClick={() => setSleeveType(s)}>
                    {s.charAt(0).toUpperCase() + s.slice(1)} sleeve
                  </button>
                ))}
              </div>

              <div className="nav-row">
                <span />
                <button className="btn-next" onClick={() => setStep(2)}>Next: Customise parts →</button>
              </div>
            </div>
          )}

          {/* ─── STEP 2: PARTS ─── */}
          {step === 2 && (
            <div className="panel">
              <div className="panel-title">Customise individual parts</div>
              <div className="apply-row">
                <span className="apply-label">Quick apply:</span>
                <button className="apply-btn" onClick={applyAllFromActive}>Apply colour to all parts</button>
              </div>

              <div className="parts-list">
                {PART_LIST.map(({ key, label }) => (
                  <button
                    key={key}
                    className={`part-row${activePart === key ? ' selected' : ''}`}
                    onClick={() => setActivePart(key)}
                  >
                    <span className="part-swatch" style={{ background: partColors[key].hex, border: partColors[key].hex === '#FFFFFF' ? '1px solid #ddd' : undefined }} />
                    <span className="part-name">{label}</span>
                    <span className="part-badge">{partColors[key].name}</span>
                    <span className="part-chevron">›</span>
                  </button>
                ))}
              </div>

              <div className="part-picker">
                <div className="picker-for">Colour for <strong>{activePart}</strong></div>
                <SwatchGrid colors={COLORS} selected={partColors[activePart].hex} onSelect={handlePartColor} />
              </div>

              <div className="nav-row">
                <button className="btn-back" onClick={() => setStep(1)}>← Back</button>
                <button className="btn-next" onClick={() => setStep(3)}>Next: Add logo →</button>
              </div>
            </div>
          )}

          {/* ─── STEP 3: LOGO ─── */}
          {step === 3 && (
            <div className="panel">
              <div className="panel-title">Upload your logo <span className="optional">(optional)</span></div>

              <label className="upload-zone">
                <input type="file" accept="image/*" style={{ display: 'none' }} onChange={handleLogoUpload} />
                <div className="upload-icon">⬆</div>
                <div className="upload-text">Drag & drop or click to upload</div>
                <div className="upload-hint">PNG, SVG, or JPG · max 5 MB · transparent bg recommended</div>
              </label>

              <div className="logo-preview-area">
                {logoData
                  ? <img src={logoData} alt="Logo preview" style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }} />
                  : <span className="preview-placeholder">Logo preview will appear here</span>
                }
              </div>

              <div className="section-title">Logo position</div>
              <div className="pos-grid">
                {POSITIONS.map(p => (
                  <button
                    key={p.id}
                    className={`pos-btn${logoPosition === p.id ? ' active' : ''}`}
                    onClick={() => setLogoPosition(p.id)}
                  >
                    {p.icon}
                  </button>
                ))}
              </div>

              <div className="slider-row">
                <div className="slider-label">
                  <span>Logo size</span>
                  <span className="slider-val">{logoSize}%</span>
                </div>
                <input type="range" min="10" max="100" value={logoSize} step="5" onChange={e => setLogoSize(+e.target.value)} />
              </div>

              <div className="nav-row">
                <button className="btn-back" onClick={() => setStep(2)}>← Back</button>
                <button className="btn-next" onClick={() => setStep(4)}>Next: Size →</button>
              </div>
            </div>
          )}

          {/* ─── STEP 4: SIZE ─── */}
          {step === 4 && (
            <div className="panel">
              <div className="panel-title">Choose your size</div>
              <div className="size-row">
                {SIZES.map(s => (
                  <button key={s} className={`size-btn${size === s ? ' active' : ''}`} onClick={() => setSize(s)}>{s}</button>
                ))}
              </div>
              <p className="note" style={{ marginBottom: '1rem' }}>
                📏 Standard sizes based on chest circumference —{' '}
                <button className="link-btn" onClick={() => setShowChart(v => !v)}>view size chart</button>
              </p>

              {showChart && (
                <div className="size-chart">
                  <table>
                    <thead>
                      <tr><th>Size</th><th>Chest</th><th>Shoulder</th><th>Sleeve</th></tr>
                    </thead>
                    <tbody>
                      {[['S','36–38″','16.5″','8.5″'],['M','38–40″','17.5″','9″'],['L','40–42″','18.5″','9.5″'],['XL','42–44″','19.5″','10″'],['XXL','44–46″','20.5″','10.5″']].map(r => (
                        <tr key={r[0]}><td>{r[0]}</td><td>{r[1]}</td><td>{r[2]}</td><td>{r[3]}</td></tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              <hr className="divider" />
              <div className="custom-header">
                <div className="section-title" style={{ margin: 0 }}>Custom measurements</div>
                <label className="toggle-check">
                  <input type="checkbox" checked={customEnabled} onChange={e => setCustomEnabled(e.target.checked)} />
                  <span>Enable</span>
                </label>
              </div>
              <div className={`custom-fields${customEnabled ? '' : ' disabled'}`}>
                <div className="field-grid">
                  {[['Chest (in)', 'e.g. 40'], ['Shoulder (in)', 'e.g. 17'], ['Hip (in)', 'e.g. 38'], ['Sleeve (in)', 'e.g. 9']].map(([label, ph]) => (
                    <div key={label} className="field-group">
                      <label>{label}</label>
                      <input type="number" placeholder={ph} disabled={!customEnabled} />
                    </div>
                  ))}
                </div>
                <p className="note">ℹ Measure over a well-fitting garment. Custom orders may take 2–3 extra days.</p>
              </div>

              <div className="nav-row">
                <button className="btn-back" onClick={() => setStep(3)}>← Back</button>
                <button className="btn-next btn-cart">Add to cart →</button>
              </div>
            </div>
          )}
        </div>

        {/* Right – 3D Live Preview */}
        <div className="preview-col">
          <div className="preview-panel">
            <div className="preview-label">Live Preview</div>
            <div className="viewer-wrap">
              <TShirtViewer
                partColors={partColors}
                sleeveType={sleeveType}
                logoData={logoData}
                logoPosition={logoPosition}
                logoSize={logoSize}
              />
            </div>
            <div className="preview-hint">Drag to rotate · Scroll to zoom</div>
            <hr className="divider" />
            <div className="summary-list">
              <div className="summary-row">
                <span className="summary-key">Style</span>
                <span className="summary-badge">{summaryStyle}</span>
              </div>
              <div className="summary-row">
                <span className="summary-key">Sleeve</span>
                <span className="summary-badge">{sleeveType === 'half' ? 'Half' : 'Full'}</span>
              </div>
              <div className="summary-row">
                <span className="summary-key">Logo</span>
                <span className="summary-badge">{logoData ? `${logoPosition} · ${logoSize}%` : 'None'}</span>
              </div>
              <div className="summary-row">
                <span className="summary-key">Size</span>
                <span className="summary-badge">{size}</span>
              </div>
            </div>
            <button className="btn-next btn-full" style={{ marginTop: '1rem', width: '100%' }} onClick={() => setStep(4)}>
              Add to cart →
            </button>
          </div>
        </div>
      </main>
    </div>
  )
}
