# Atelier — AI Virtual Try-On

A production-shaped reference implementation of a drag-and-drop virtual
try-on lookbook: users pick an avatar, drag in any number of garments, and
get back a single AI-rendered outfit image — no PNG overlays, no CSS
positioning. Garment pixels are actually regenerated onto the body by a
real virtual try-on diffusion model.

## Why Replicate-hosted IDM-VTON, not a local model

IDM-VTON and CatVTON are real diffusion models that need a GPU to run
(several GB of VRAM, tens of seconds per inference). This repo does **not**
bundle model weights or a GPU server, because:

1. There's no way to hand you a working GPU inference box inside a text
   repo — you need actual hardware or a hosted GPU provider.
2. Replicate already hosts maintained versions of IDM-VTON and CatVTON
   behind a plain HTTP API, which is how most teams ship this in
   production without operating their own GPU fleet.

The codebase is built so this is a swappable detail, not a hardcoded
assumption:

```
backend/src/services/providers/
  index.ts              <- factory, reads VTON_PROVIDER env var
  replicateProvider.ts  <- default: calls Replicate's hosted IDM-VTON/CatVTON
  selfHostedProvider.ts <- stub for your own GPU server, same interface
```

Every provider implements one interface (`VtonProvider.generate()`), so
adding Kolors, a FLUX-inpainting pipeline, or your own fine-tuned model
later means writing one new class and adding one line to the factory —
nothing in the queue, routes, or frontend changes.

## Architecture

```
frontend (Next.js/React/TS)          backend (Node/Express/TS)
─────────────────────────           ──────────────────────────
AvatarSelector                       POST /api/tryon/upload  -> storage
GarmentDropzone  ──upload──────────> POST /api/tryon         -> queue.submit()
OutfitCanvas     <──poll status──── GET  /api/tryon/:jobId
HistoryPanel                                  │
Toolbar (undo/redo)                           ▼
                                      TryOnQueue (bounded concurrency)
                                               │
                                               ▼
                                      outfitComposer.composeOutfit()
                                        1. classify garments
                                        2. sort into layer order
                                        3. chain sequential VTON calls
                                        4. persist final image to storage
                                               │
                                               ▼
                                      VtonProvider (Replicate / self-hosted)
```

### Multi-garment layering

Most VTON models (including IDM-VTON and CatVTON) apply **one garment
region per inference call**. To render "shirt + jacket + trousers" as a
single coherent outfit, `outfitComposer.ts` chains calls: the output image
from applying the trousers becomes the input "person image" for applying
the shirt, and that output becomes the input for the jacket. Layer order
is centralized in `types.ts` (`LAYER_ORDER` / `ACCESSORY_LAYER_ORDER`) so
outerwear always renders after shirts, scarves always render after
jackets, etc. — see `layeringEngine.ts`.

Garment classification (`garmentClassifier.ts`) is a keyword lookup today.
It's isolated behind `resolveGarmentCategories()` specifically so it can be
replaced with a real image classifier (e.g. zero-shot CLIP) without
touching layering, queueing, or routes.

### What the backend does NOT do

- **Face, hair, hands, pose, camera angle, background**: left untouched.
  This is a property of IDM-VTON/CatVTON's training objective (they're
  built to preserve identity and only edit the targeted clothing region),
  not something this orchestration layer enforces. If you swap in a model
  without that guarantee, add a post-process (e.g. face restoration) step
  in `outfitComposer.ts`.
- **Accessories (bags, jewelry, glasses, hats, shoes)**: routed through
  the same `VtonProvider` interface for architectural consistency, but
  garment-VTON models are trained on clothing, not accessories. Treat
  accessory support as a placeholder until you wire in an
  accessory-specific pipeline (or a general inpainting model) — this is
  flagged in code comments in `outfitComposer.ts` and `replicateProvider.ts`.
- **Dresses + separate lower-body garment** selected simultaneously: the
  system warns (`layeringEngine.validateCombination`) rather than guessing.

## Setup

### Backend

```bash
cd backend
cp .env.example .env
# add your Replicate API token: https://replicate.com/account/api-tokens
npm install
npm run dev        # http://localhost:4000
```

### Frontend

```bash
cd frontend
cp .env.local.example .env.local
npm install
npm run dev         # http://localhost:3000
```

Both `npm install` + `npx tsc --noEmit` have been verified to pass cleanly
in this environment.

## Extending to future garment types

Add a keyword bucket in `garmentClassifier.ts` and, if it's a new
top-level category (not just a synonym), a case in `LAYER_ORDER` /
`ACCESSORY_LAYER_ORDER` in `types.ts`. Dresses, sarees, and ethnic wear are
already modeled as a `dress` category; extending to jewelry/watches/bags
just means adding more `AccessorySlot` keyword buckets — no frontend
changes required since the dropzone treats every upload generically.

## Performance & scaling notes

- `TryOnQueue` is an in-memory bounded-concurrency queue — fine for a
  single-process demo. For real traffic, swap it for BullMQ + Redis (or
  SQS); the HTTP contract (`submit -> jobId -> poll`) doesn't change.
- `outfitCache.ts` is an in-memory Map keyed by a hash of
  (avatar + garment set). Swap for Redis with a TTL in production so
  repeated identical requests across server instances hit the cache too.
- `storage.ts` supports local disk (dev) or S3 (prod); generated images
  are re-saved to your own storage so returned URLs stay stable even if a
  provider's URLs expire.
