import "dotenv/config";
import express from "express";
import cors from "cors";
import path from "path";
import { createTryonRouter } from "./routes/tryon";
import { TryOnQueue } from "./queue/tryonQueue";
import { createVtonProvider } from "./services/providers";

const app = express();
const port = process.env.PORT ?? 4000;

app.use(cors());
app.use(express.json({ limit: "10mb" }));

// Serve locally-stored generated/uploaded images when STORAGE_DRIVER=local
app.use("/static", express.static(path.resolve(process.env.LOCAL_STORAGE_DIR ?? "./storage")));

const provider = createVtonProvider();
const queue = new TryOnQueue(provider, /* concurrency */ 2);

app.use("/api/tryon", createTryonRouter(queue));

app.get("/health", (_req, res) => res.json({ ok: true, provider: provider.name }));

app.listen(port, () => {
  console.log(`VTON backend listening on :${port} (provider: ${provider.name})`);
});
