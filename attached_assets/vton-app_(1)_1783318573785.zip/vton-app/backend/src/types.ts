/**
 * Core domain types shared across the backend.
 */

export type GarmentCategory =
  | "upper_body"
  | "lower_body"
  | "outerwear"
  | "dress"
  | "accessory";

export type AccessorySlot =
  | "scarf"
  | "hat"
  | "glasses"
  | "watch"
  | "jewelry"
  | "bag"
  | "shoes"
  | "other";

/** Layer order, lowest number renders/composites first (closest to skin). */
export const LAYER_ORDER: Record<GarmentCategory, number> = {
  lower_body: 10,
  dress: 15,
  upper_body: 20,
  outerwear: 30,
  accessory: 40,
};

/** Fine-grained accessory ordering (accessories still respect their own stacking). */
export const ACCESSORY_LAYER_ORDER: Record<AccessorySlot, number> = {
  watch: 41,
  jewelry: 42,
  glasses: 43,
  bag: 44,
  shoes: 45,
  hat: 46,
  scarf: 47, // scarves sit above outerwear/jackets
  other: 48,
};

export interface GarmentInput {
  id: string;
  /** URL or storage key of the uploaded garment image (already background-stripped if possible). */
  imageUrl: string;
  /** Optional hint from the client; classifier will still validate/override. */
  typeHint?: string;
  category?: GarmentCategory;
  accessorySlot?: AccessorySlot;
  /** Whether an upper-body garment should be tucked into lower-body garment. */
  tuck?: boolean;
}

export interface TryOnRequest {
  avatarImageUrl: string;
  garments: GarmentInput[];
  /** Reuse identical avatar+garment combos from cache if present. */
  allowCache?: boolean;
}

export type JobStatus = "queued" | "processing" | "completed" | "failed";

export interface TryOnJob {
  id: string;
  status: JobStatus;
  createdAt: string;
  updatedAt: string;
  request: TryOnRequest;
  resultImageUrl?: string;
  error?: string;
  /** Which provider call chain produced this (useful for debugging multi-garment composition). */
  steps?: { garmentId: string; category: GarmentCategory; providerCallId?: string }[];
}

/** Provider-agnostic single-garment application call. */
export interface VtonGenerateParams {
  personImageUrl: string;
  garmentImageUrl: string;
  category: GarmentCategory;
  /** Free-form description to help the model preserve prints/logos/texture. */
  garmentDescription?: string;
}

export interface VtonGenerateResult {
  imageUrl: string;
  providerCallId: string;
  raw?: unknown;
}

/** Every VTON backend (IDM-VTON, CatVTON, self-hosted, etc.) implements this. */
export interface VtonProvider {
  name: string;
  generate(params: VtonGenerateParams): Promise<VtonGenerateResult>;
}
