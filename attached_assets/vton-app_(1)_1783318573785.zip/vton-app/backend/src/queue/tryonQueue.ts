import { v4 as uuid } from "uuid";
import { TryOnJob, TryOnRequest, VtonProvider } from "../types";
import { composeOutfit } from "../services/outfitComposer";

/**
 * Minimal async job queue with bounded concurrency, in-memory job store,
 * and status polling. This keeps the reference implementation dependency
 * -free (no Redis required to run the demo).
 *
 * PRODUCTION NOTE: swap this for BullMQ + Redis (or SQS) once you need
 * multi-process workers, retries-with-backoff, or job persistence across
 * restarts. The HTTP-facing contract (submit -> job id -> poll status)
 * stays identical, so routes/tryon.ts would not need to change.
 */
export class TryOnQueue {
  private jobs = new Map<string, TryOnJob>();
  private pending: string[] = [];
  private active = 0;

  constructor(private provider: VtonProvider, private concurrency = 2) {}

  submit(request: TryOnRequest): TryOnJob {
    const now = new Date().toISOString();
    const job: TryOnJob = {
      id: uuid(),
      status: "queued",
      createdAt: now,
      updatedAt: now,
      request,
    };
    this.jobs.set(job.id, job);
    this.pending.push(job.id);
    this.drain();
    return job;
  }

  get(jobId: string): TryOnJob | undefined {
    return this.jobs.get(jobId);
  }

  private drain() {
    while (this.active < this.concurrency && this.pending.length > 0) {
      const jobId = this.pending.shift()!;
      const job = this.jobs.get(jobId);
      if (!job) continue;
      this.active++;
      this.runJob(job).finally(() => {
        this.active--;
        this.drain();
      });
    }
  }

  private async runJob(job: TryOnJob) {
    job.status = "processing";
    job.updatedAt = new Date().toISOString();

    try {
      const result = await composeOutfit(job.request, this.provider);
      job.status = "completed";
      job.resultImageUrl = result.finalImageUrl;
      job.steps = result.steps;
      job.updatedAt = new Date().toISOString();
    } catch (err) {
      job.status = "failed";
      job.error = err instanceof Error ? err.message : "Unknown error";
      job.updatedAt = new Date().toISOString();
    }
  }
}
