import {
  ACCESSORY_LAYER_ORDER,
  GarmentInput,
  LAYER_ORDER,
} from "../types";

/**
 * Decides the order in which garments are composited onto the avatar and
 * whether an upper-body garment should be tucked into a lower-body one.
 *
 * Rule of thumb encoded here:
 *   lower_body / dress  -> shirts/tops -> outerwear -> accessories
 *   (accessories sub-ordered: watch/jewelry/glasses/bag/shoes/hat/scarf)
 *
 * Because most VTON models (IDM-VTON, CatVTON) apply ONE garment region
 * per inference call, multi-garment outfits are built by chaining calls:
 * the output image of step N becomes the "person image" input for step
 * N+1. This function returns that ordered chain.
 */
export function sortGarmentsForApplication(garments: GarmentInput[]): GarmentInput[] {
  return [...garments].sort((a, b) => {
    const orderA = orderFor(a);
    const orderB = orderFor(b);
    return orderA - orderB;
  });
}

function orderFor(g: GarmentInput): number {
  if (g.category === "accessory" && g.accessorySlot) {
    return ACCESSORY_LAYER_ORDER[g.accessorySlot];
  }
  if (!g.category) return 999; // unclassified garments go last, flagged upstream
  return LAYER_ORDER[g.category];
}

/**
 * Determines whether an upper-body garment should render tucked into the
 * lower-body garment. Defaults to the garment's explicit `tuck` flag if
 * provided by the user; otherwise infers from garment type heuristics
 * (e.g. dress shirts commonly tuck, hoodies/t-shirts commonly don't).
 */
export function shouldTuck(upperGarment: GarmentInput): boolean {
  if (typeof upperGarment.tuck === "boolean") return upperGarment.tuck;
  const hint = (upperGarment.typeHint ?? "").toLowerCase();
  if (hint.includes("shirt") && !hint.includes("t-shirt") && !hint.includes("tshirt")) {
    return true; // formal/button shirts default to tucked
  }
  return false;
}

/** Validates a garment combination and returns human-readable warnings
 *  (e.g. two lower-body garments selected at once) without blocking
 *  generation — the caller decides whether to surface these to the user. */
export function validateCombination(garments: GarmentInput[]): string[] {
  const warnings: string[] = [];
  const counts: Record<string, number> = {};
  for (const g of garments) {
    const key = g.category ?? "unclassified";
    counts[key] = (counts[key] ?? 0) + 1;
  }
  if ((counts["lower_body"] ?? 0) > 1) {
    warnings.push("Multiple lower-body garments selected; only the last applied will be visible.");
  }
  if ((counts["upper_body"] ?? 0) > 1) {
    warnings.push("Multiple upper-body garments selected; only the last applied will be visible.");
  }
  if ((counts["dress"] ?? 0) > 0 && (counts["lower_body"] ?? 0) > 0) {
    warnings.push("A dress and lower-body garment were both selected; the lower-body garment may be hidden by the dress.");
  }
  if (counts["unclassified"]) {
    warnings.push(`${counts["unclassified"]} garment(s) could not be auto-classified; please confirm their category.`);
  }
  return warnings;
}
