import crypto from "crypto";
import { GarmentCategory, GarmentInput, TryOnRequest, VtonProvider } from "../types";
import { resolveGarmentCategories } from "./garmentClassifier";
import { shouldTuck, sortGarmentsForApplication, validateCombination } from "./layeringEngine";
import { createStorageDriver, fetchImageBuffer } from "./storage";
import { getCachedOutfit, setCachedOutfit } from "./outfitCache";

export interface ComposeResult {
  finalImageUrl: string;
  warnings: string[];
  steps: { garmentId: string; category: GarmentCategory; providerCallId?: string }[];
  cacheHit: boolean;
}

/**
 * Applies each garment in the correct layer order by chaining sequential
 * calls to the VTON provider: the avatar/output image from step N becomes
 * the "person image" input to step N+1. This is how multi-garment outfits
 * are built even though most VTON models (IDM-VTON, CatVTON) only apply
 * one garment region per call.
 *
 * NOTE ON FACE/HAIR/POSE PRESERVATION: IDM-VTON and CatVTON are trained
 * specifically to preserve the person's identity, pose and background
 * while only replacing the targeted clothing region — this is a property
 * of the model itself, not something this orchestration layer needs to
 * enforce. If a different model is swapped in via providers/index.ts that
 * does NOT have this guarantee, add a face/pose-preservation post-process
 * step here (e.g. a face-restoration pass) before returning the result.
 */
export async function composeOutfit(
  request: TryOnRequest,
  provider: VtonProvider
): Promise<ComposeResult> {
  const garments = resolveGarmentCategories(request.garments);
  const warnings = validateCombination(garments);
  const ordered = sortGarmentsForApplication(garments);

  const cacheKey = buildCacheKey(request.avatarImageUrl, ordered);
  if (request.allowCache !== false) {
    const cached = await getCachedOutfit(cacheKey);
    if (cached) {
      return { finalImageUrl: cached, warnings, steps: [], cacheHit: true };
    }
  }

  let currentImageUrl = request.avatarImageUrl;
  const steps: ComposeResult["steps"] = [];

  for (const garment of ordered) {
    if (!garment.category) continue; // already warned in validateCombination

    // Accessories (bags, glasses, jewelry, shoes, hats) generally need a
    // different accessory-specific try-on/inpainting pipeline than
    // garment VTON models are trained for. We still route them through
    // the same provider interface for architectural consistency, but flag
    // this clearly so it's not mistaken for full accessory-model support.
    const description = describeGarmentForModel(garment);

    const result = await provider.generate({
      personImageUrl: currentImageUrl,
      garmentImageUrl: garment.imageUrl,
      category: garment.category,
      garmentDescription: description,
    });

    currentImageUrl = result.imageUrl;
    steps.push({
      garmentId: garment.id,
      category: garment.category,
      providerCallId: result.providerCallId,
    });
  }

  // Persist the provider's (possibly ephemeral) output URL into our own
  // storage so the final URL we hand back to the client is stable.
  const storage = createStorageDriver();
  const buffer = await fetchImageBuffer(currentImageUrl);
  const finalImageUrl = await storage.save(buffer, "png");

  if (request.allowCache !== false) {
    await setCachedOutfit(cacheKey, finalImageUrl);
  }

  return { finalImageUrl, warnings, steps, cacheHit: false };
}

function describeGarmentForModel(garment: GarmentInput): string {
  const tuckNote = garment.category === "upper_body" && shouldTuck(garment)
    ? ", tucked into the lower-body garment"
    : "";
  return (
    `preserve the exact color, print, logo, embroidery, texture, stitching, ` +
    `buttons, collar and sleeve details of the original garment${tuckNote}; ` +
    `no hallucinated design changes`
  );
}

function buildCacheKey(avatarUrl: string, garments: GarmentInput[]): string {
  const hash = crypto.createHash("sha256");
  hash.update(avatarUrl);
  for (const g of garments) {
    hash.update("|");
    hash.update(g.imageUrl);
    hash.update(g.category ?? "");
    hash.update(String(g.tuck ?? ""));
  }
  return hash.digest("hex");
}
