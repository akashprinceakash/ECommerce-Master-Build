import { GarmentCategory, AccessorySlot, GarmentInput } from "../types";

/**
 * Maps free-form garment type strings (from UI dropdown, filename, or a
 * future ML-based image classifier) to a canonical GarmentCategory.
 *
 * This is intentionally a simple lookup table today. Swap the body of
 * `classifyByHint` for a call to a real image classifier (e.g. a CLIP
 * zero-shot classifier or a small fine-tuned model) without touching
 * any other part of the system — everything downstream only cares
 * about the returned GarmentCategory / AccessorySlot.
 */

const UPPER_BODY_KEYWORDS = [
  "shirt", "polo", "t-shirt", "tshirt", "tee", "blouse", "top", "sweater",
  "hoodie", "sweatshirt", "tank", "camisole", "kurta",
];

const LOWER_BODY_KEYWORDS = [
  "pant", "trouser", "jean", "chino", "short", "skirt", "legging",
  "jogger", "culotte", "palazzo", "dhoti",
];

const OUTERWEAR_KEYWORDS = [
  "jacket", "coat", "blazer", "cardigan", "windbreaker", "parka", "vest",
  "overcoat", "bomber",
];

const DRESS_KEYWORDS = ["dress", "gown", "saree", "sari", "jumpsuit", "romper"];

const ACCESSORY_KEYWORDS: Record<AccessorySlot, string[]> = {
  scarf: ["scarf", "stole", "shawl"],
  hat: ["hat", "cap", "beanie", "beret"],
  glasses: ["glasses", "sunglasses", "shades"],
  watch: ["watch"],
  jewelry: ["jewelry", "necklace", "bracelet", "earring", "ring"],
  bag: ["bag", "purse", "backpack", "handbag", "clutch"],
  shoes: ["shoe", "sneaker", "boot", "heel", "sandal"],
  other: [],
};

function matchesAny(value: string, keywords: string[]): boolean {
  const v = value.toLowerCase();
  return keywords.some((k) => v.includes(k));
}

export interface ClassificationResult {
  category: GarmentCategory;
  accessorySlot?: AccessorySlot;
}

export function classifyByHint(hint: string): ClassificationResult {
  if (matchesAny(hint, DRESS_KEYWORDS)) return { category: "dress" };
  if (matchesAny(hint, OUTERWEAR_KEYWORDS)) return { category: "outerwear" };
  if (matchesAny(hint, UPPER_BODY_KEYWORDS)) return { category: "upper_body" };
  if (matchesAny(hint, LOWER_BODY_KEYWORDS)) return { category: "lower_body" };

  for (const slot of Object.keys(ACCESSORY_KEYWORDS) as AccessorySlot[]) {
    if (matchesAny(hint, ACCESSORY_KEYWORDS[slot])) {
      return { category: "accessory", accessorySlot: slot };
    }
  }

  // Safe default: treat unknown garments as upper body rather than silently
  // dropping them; the UI surfaces a "couldn't classify" warning so the
  // user can confirm/override manually.
  return { category: "upper_body" };
}

/** Ensures every garment in a request has a resolved category, using the
 *  client-supplied hint/category first and falling back to classification. */
export function resolveGarmentCategories(garments: GarmentInput[]): GarmentInput[] {
  return garments.map((g) => {
    if (g.category) return g;
    const hint = g.typeHint ?? "";
    const { category, accessorySlot } = classifyByHint(hint);
    return { ...g, category, accessorySlot };
  });
}
