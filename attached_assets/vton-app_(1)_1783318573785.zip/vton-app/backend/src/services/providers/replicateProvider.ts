import { VtonGenerateParams, VtonGenerateResult, VtonProvider } from "../../types";

/**
 * VtonProvider implementation backed by Replicate's hosted IDM-VTON /
 * CatVTON models. This is the recommended default because it avoids
 * standing up and maintaining your own GPU inference server.
 *
 * To swap models: set REPLICATE_IDM_VTON_MODEL / REPLICATE_CATVTON_MODEL
 * in .env. To swap providers entirely (e.g. a self-hosted inference
 * server), see providers/selfHostedProvider.ts and providers/index.ts —
 * no other file in the codebase needs to change.
 */

const REPLICATE_API_BASE = "https://api.replicate.com/v1";

interface ReplicateCreatePredictionResponse {
  id: string;
  status: string;
  urls: { get: string; cancel: string };
  output?: string | string[];
  error?: string;
}

export class ReplicateVtonProvider implements VtonProvider {
  name = "replicate";

  constructor(
    private apiToken: string,
    private modelSlug: string, // e.g. "cuuupid/idm-vton"
    private pollIntervalMs = 2000,
    private timeoutMs = 120_000
  ) {}

  async generate(params: VtonGenerateParams): Promise<VtonGenerateResult> {
    const prediction = await this.createPrediction(params);
    const finalResult = await this.pollUntilDone(prediction.urls.get);

    const outputUrl = Array.isArray(finalResult.output)
      ? finalResult.output[0]
      : finalResult.output;

    if (!outputUrl) {
      throw new Error(
        `Replicate prediction ${finalResult.id} completed without an output image`
      );
    }

    return {
      imageUrl: outputUrl,
      providerCallId: finalResult.id,
      raw: finalResult,
    };
  }

  private async createPrediction(
    params: VtonGenerateParams
  ): Promise<ReplicateCreatePredictionResponse> {
    // IDM-VTON's public Replicate schema takes human_img / garm_img plus
    // a garment_des text hint used to help preserve print/logo fidelity
    // in the diffusion prompt. CatVTON's schema is very similar
    // (person_image / cloth_image). Adjust field names here if you pin
    // a different model version.
    const input = {
      human_img: params.personImageUrl,
      garm_img: params.garmentImageUrl,
      garment_des:
        params.garmentDescription ??
        "the exact garment as shown, preserving original color, print, logo, texture and fit",
      category: mapCategoryToModelLabel(params.category),
    };

    const res = await fetch(`${REPLICATE_API_BASE}/models/${this.modelSlug}/predictions`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${this.apiToken}`,
        "Content-Type": "application/json",
        Prefer: "wait=30", // ask Replicate to hold the connection briefly if it finishes fast
      },
      body: JSON.stringify({ input }),
    });

    if (!res.ok) {
      const body = await res.text();
      throw new Error(`Replicate API error (${res.status}): ${body}`);
    }

    return (await res.json()) as ReplicateCreatePredictionResponse;
  }

  private async pollUntilDone(
    getUrl: string
  ): Promise<ReplicateCreatePredictionResponse> {
    const start = Date.now();
    while (Date.now() - start < this.timeoutMs) {
      const res = await fetch(getUrl, {
        headers: { Authorization: `Bearer ${this.apiToken}` },
      });
      if (!res.ok) {
        throw new Error(`Replicate poll error (${res.status}): ${await res.text()}`);
      }
      const data = (await res.json()) as ReplicateCreatePredictionResponse;

      if (data.status === "succeeded") return data;
      if (data.status === "failed" || data.status === "canceled") {
        throw new Error(`Replicate prediction ${data.status}: ${data.error ?? "unknown error"}`);
      }
      await new Promise((r) => setTimeout(r, this.pollIntervalMs));
    }
    throw new Error("Replicate prediction timed out");
  }
}

function mapCategoryToModelLabel(category: VtonGenerateParams["category"]): string {
  switch (category) {
    case "upper_body":
      return "upper_body";
    case "lower_body":
      return "lower_body";
    case "outerwear":
      return "upper_body"; // most VTON models don't distinguish outerwear from tops
    case "dress":
      return "dresses";
    case "accessory":
      return "upper_body"; // accessories typically need a different pipeline; see README caveats
    default:
      return "upper_body";
  }
}
