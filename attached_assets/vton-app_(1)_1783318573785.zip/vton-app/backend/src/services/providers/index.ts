import { VtonProvider } from "../../types";
import { ReplicateVtonProvider } from "./replicateProvider";
import { SelfHostedVtonProvider } from "./selfHostedProvider";

/**
 * Single point of configuration for which VTON model backs the app.
 * Everything else in the codebase depends only on the VtonProvider
 * interface, so adding a new model (Kolors, a FLUX-inpainting pipeline,
 * etc.) means: write a class implementing VtonProvider, add one case
 * here, done.
 */
export function createVtonProvider(): VtonProvider {
  const which = process.env.VTON_PROVIDER ?? "replicate";

  switch (which) {
    case "replicate": {
      const token = process.env.REPLICATE_API_TOKEN;
      if (!token) {
        throw new Error(
          "REPLICATE_API_TOKEN is required when VTON_PROVIDER=replicate. See backend/.env.example."
        );
      }
      const model = process.env.REPLICATE_IDM_VTON_MODEL ?? "cuuupid/idm-vton";
      return new ReplicateVtonProvider(token, model);
    }

    case "replicate-catvton": {
      const token = process.env.REPLICATE_API_TOKEN;
      if (!token) throw new Error("REPLICATE_API_TOKEN is required.");
      const model = process.env.REPLICATE_CATVTON_MODEL ?? "zsxkib/catvton";
      return new ReplicateVtonProvider(token, model);
    }

    case "self-hosted": {
      const url = process.env.SELF_HOSTED_VTON_URL;
      if (!url) {
        throw new Error(
          "SELF_HOSTED_VTON_URL is required when VTON_PROVIDER=self-hosted."
        );
      }
      return new SelfHostedVtonProvider(url);
    }

    default:
      throw new Error(`Unknown VTON_PROVIDER "${which}"`);
  }
}
