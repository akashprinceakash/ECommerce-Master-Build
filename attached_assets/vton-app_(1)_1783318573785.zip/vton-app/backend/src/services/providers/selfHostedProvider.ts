import { VtonGenerateParams, VtonGenerateResult, VtonProvider } from "../../types";

/**
 * Example provider for a self-hosted VTON inference server (e.g. your own
 * GPU box running IDM-VTON or CatVTON via a small FastAPI/Flask wrapper).
 *
 * Expected server contract (adjust to match your actual server):
 *   POST {SELF_HOSTED_VTON_URL}
 *   body: { person_image_url, garment_image_url, category, description }
 *   response: { image_url, call_id }
 *
 * This class exists to demonstrate that swapping the underlying model
 * implementation requires touching ONLY this file plus a one-line change
 * in providers/index.ts — nothing in routes/, queue/, or the frontend
 * needs to know or care which model actually ran.
 */
export class SelfHostedVtonProvider implements VtonProvider {
  name = "self-hosted";

  constructor(private endpointUrl: string) {}

  async generate(params: VtonGenerateParams): Promise<VtonGenerateResult> {
    const res = await fetch(this.endpointUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        person_image_url: params.personImageUrl,
        garment_image_url: params.garmentImageUrl,
        category: params.category,
        description: params.garmentDescription,
      }),
    });

    if (!res.ok) {
      throw new Error(`Self-hosted VTON server error (${res.status}): ${await res.text()}`);
    }

    const data = (await res.json()) as { image_url: string; call_id: string };
    return { imageUrl: data.image_url, providerCallId: data.call_id, raw: data };
  }
}
