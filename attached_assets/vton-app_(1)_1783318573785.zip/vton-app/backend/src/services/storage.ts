import fs from "fs/promises";
import path from "path";
import { v4 as uuid } from "uuid";
import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";

/**
 * Storage abstraction so generated outfit images (and uploaded garment
 * images) can be persisted to disk locally in dev, or to S3 / any
 * S3-compatible bucket (Cloudflare R2, MinIO, etc.) in production.
 */
export interface StorageDriver {
  /** Persists a buffer and returns a publicly-accessible URL. */
  save(buffer: Buffer, extension: string): Promise<string>;
}

export class LocalStorageDriver implements StorageDriver {
  constructor(private baseDir: string, private publicBasePath = "/static") {}

  async save(buffer: Buffer, extension: string): Promise<string> {
    await fs.mkdir(this.baseDir, { recursive: true });
    const filename = `${uuid()}.${extension}`;
    await fs.writeFile(path.join(this.baseDir, filename), buffer);
    return `${this.publicBasePath}/${filename}`;
  }
}

export class S3StorageDriver implements StorageDriver {
  private client: S3Client;

  constructor(
    private bucket: string,
    region: string,
    private publicUrlBase?: string // e.g. CloudFront domain
  ) {
    this.client = new S3Client({ region });
  }

  async save(buffer: Buffer, extension: string): Promise<string> {
    const key = `outfits/${uuid()}.${extension}`;
    await this.client.send(
      new PutObjectCommand({
        Bucket: this.bucket,
        Key: key,
        Body: buffer,
        ContentType: extension === "png" ? "image/png" : "application/octet-stream",
      })
    );
    const base = this.publicUrlBase ?? `https://${this.bucket}.s3.amazonaws.com`;
    return `${base}/${key}`;
  }
}

export function createStorageDriver(): StorageDriver {
  const driver = process.env.STORAGE_DRIVER ?? "local";
  if (driver === "s3") {
    const bucket = process.env.S3_BUCKET;
    const region = process.env.S3_REGION;
    if (!bucket || !region) {
      throw new Error("S3_BUCKET and S3_REGION are required when STORAGE_DRIVER=s3.");
    }
    return new S3StorageDriver(bucket, region);
  }
  return new LocalStorageDriver(process.env.LOCAL_STORAGE_DIR ?? "./storage");
}

/** Fetches a remote image URL and returns its bytes (used to pull a
 *  provider's output image down before re-saving it to our own storage,
 *  so outfit URLs stay stable even if the provider's URLs expire). */
export async function fetchImageBuffer(url: string): Promise<Buffer> {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Failed to fetch image at ${url}: ${res.status}`);
  const arrayBuf = await res.arrayBuffer();
  return Buffer.from(arrayBuf);
}
