/**
 * Caches finished outfit image URLs keyed by (avatar + garment set) hash,
 * so re-requesting an identical combination is instant.
 *
 * In-memory Map is fine for a single-process dev/demo deployment. For
 * production with multiple server instances, swap this for Redis
 * (`SET key value EX 86400` / `GET key`) — the function signatures below
 * are already async so that swap requires no caller changes.
 */

const cache = new Map<string, string>();

export async function getCachedOutfit(key: string): Promise<string | null> {
  return cache.get(key) ?? null;
}

export async function setCachedOutfit(key: string, imageUrl: string): Promise<void> {
  cache.set(key, imageUrl);
}
