import { Router } from "express";
import multer from "multer";
import { v4 as uuid } from "uuid";
import { TryOnQueue } from "../queue/tryonQueue";
import { createStorageDriver } from "../services/storage";
import { TryOnRequest } from "../types";

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 15 * 1024 * 1024 } });

export function createTryonRouter(queue: TryOnQueue): Router {
  const router = Router();

  /**
   * POST /api/tryon
   * body: TryOnRequest (avatarImageUrl + garments[])
   * returns: { jobId } — poll GET /api/tryon/:jobId for status/result
   */
  router.post("/", (req, res) => {
    const request = req.body as TryOnRequest;

    if (!request?.avatarImageUrl) {
      return res.status(400).json({ error: "avatarImageUrl is required" });
    }
    if (!Array.isArray(request.garments) || request.garments.length === 0) {
      return res.status(400).json({ error: "At least one garment is required" });
    }

    const job = queue.submit(request);
    res.status(202).json({ jobId: job.id, status: job.status });
  });

  /**
   * GET /api/tryon/:jobId
   * returns current job status, and resultImageUrl once completed.
   * Frontend polls this on an interval to show progress.
   */
  router.get("/:jobId", (req, res) => {
    const job = queue.get(req.params.jobId);
    if (!job) return res.status(404).json({ error: "Job not found" });
    res.json(job);
  });

  /**
   * POST /api/tryon/upload
   * multipart/form-data with a single "file" field (avatar or garment image).
   * Returns a stable URL to reference in subsequent /api/tryon requests.
   */
  router.post("/upload", upload.single("file"), async (req, res) => {
    if (!req.file) return res.status(400).json({ error: "file is required" });

    const storage = createStorageDriver();
    const ext = (req.file.originalname.split(".").pop() || "png").toLowerCase();
    const url = await storage.save(req.file.buffer, ext);
    res.json({ url, id: uuid() });
  });

  return router;
}
