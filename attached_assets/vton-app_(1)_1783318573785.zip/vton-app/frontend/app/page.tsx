"use client";

import { useMemo, useState } from "react";
import AvatarSelector from "@/components/AvatarSelector";
import GarmentDropzone from "@/components/GarmentDropzone";
import OutfitCanvas from "@/components/OutfitCanvas";
import HistoryPanel from "@/components/HistoryPanel";
import Toolbar from "@/components/Toolbar";
import { submitTryOn, waitForTryOn } from "@/lib/api";
import { Garment, JobStatus, OutfitHistoryEntry } from "@/lib/types";

// Placeholder starter avatars — replace with your own mannequin/model
// photography. Any front-facing, neutral-pose, plain-background image works.
const STARTER_AVATARS = [
  "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&q=80",
  "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&q=80",
];

export default function Page() {
  const [avatarUrl, setAvatarUrl] = useState<string | null>(STARTER_AVATARS[0]);
  const [avatars, setAvatars] = useState<string[]>(STARTER_AVATARS);
  const [garments, setGarments] = useState<Garment[]>([]);
  const [warnings, setWarnings] = useState<string[]>([]);

  const [status, setStatus] = useState<JobStatus | "idle">("idle");
  const [error, setError] = useState<string | undefined>();

  // Undo/redo + history is modeled as a single append-only list of
  // snapshots, with a pointer for "where we currently are". Undo/redo
  // just move the pointer; generating a new outfit truncates any
  // "future" branch and appends a fresh entry, like standard editor history.
  const [history, setHistory] = useState<OutfitHistoryEntry[]>([]);
  const [pointer, setPointer] = useState(-1);

  const activeEntry = pointer >= 0 ? history[pointer] : null;
  const displayImageUrl = activeEntry?.resultImageUrl ?? null;

  const canUndo = pointer > 0;
  const canRedo = pointer >= 0 && pointer < history.length - 1;
  const canGenerate = Boolean(avatarUrl) && garments.length > 0;

  const generating = status === "queued" || status === "processing";

  function addGarment(g: Garment) {
    setGarments((prev) => [...prev, g]);
  }

  function removeGarment(id: string) {
    setGarments((prev) => prev.filter((g) => g.id !== id));
  }

  async function handleGenerate() {
    if (!avatarUrl || garments.length === 0) return;
    setError(undefined);
    setStatus("queued");

    try {
      const jobId = await submitTryOn(avatarUrl, garments);
      const finalJob = await waitForTryOn(jobId, (job) => setStatus(job.status));

      if (finalJob.status === "completed" && finalJob.resultImageUrl) {
        const entry: OutfitHistoryEntry = {
          garments: [...garments],
          resultImageUrl: finalJob.resultImageUrl,
          timestamp: Date.now(),
        };
        setHistory((prev) => [...prev.slice(0, pointer + 1), entry]);
        setPointer((p) => p + 1);
        setStatus("completed");
      } else {
        setStatus("failed");
        setError(finalJob.error ?? "Outfit generation failed");
      }
    } catch (err) {
      setStatus("failed");
      setError(err instanceof Error ? err.message : "Unexpected error");
    }
  }

  function handleUndo() {
    if (!canUndo) return;
    setPointer((p) => p - 1);
    setStatus("completed");
  }

  function handleRedo() {
    if (!canRedo) return;
    setPointer((p) => p + 1);
    setStatus("completed");
  }

  function handleSelectHistory(reversedIndex: number) {
    const realIndex = history.length - 1 - reversedIndex;
    setPointer(realIndex);
    setStatus("completed");
  }

  return (
    <main className="app-shell">
      <header className="masthead">
        <div>
          <span className="eyebrow">Atelier · AI Virtual Try-On</span>
          <h1>Lookbook Studio</h1>
        </div>
      </header>

      <div className="layout-grid">
        <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          <AvatarSelector
            avatars={avatars}
            selected={avatarUrl}
            onSelect={setAvatarUrl}
            onUpload={(url) => {
              setAvatars((prev) => [...prev, url]);
              setAvatarUrl(url);
            }}
          />
          <GarmentDropzone garments={garments} onAdd={addGarment} onRemove={removeGarment} />
        </div>

        <div>
          <OutfitCanvas displayImageUrl={displayImageUrl} status={status} error={error} />
          <Toolbar
            onGenerate={handleGenerate}
            onUndo={handleUndo}
            onRedo={handleRedo}
            canUndo={canUndo}
            canRedo={canRedo}
            canGenerate={canGenerate}
            generating={generating}
          />
          {warnings.length > 0 && (
            <div className="warning-banner">{warnings.join(" ")}</div>
          )}
        </div>

        <HistoryPanel
          history={history}
          activeIndex={history.length - 1 - pointer}
          onSelect={handleSelectHistory}
        />
      </div>
    </main>
  );
}
