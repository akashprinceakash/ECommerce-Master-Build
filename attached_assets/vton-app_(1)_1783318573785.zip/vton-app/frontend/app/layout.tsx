import type { Metadata } from "next";
import "../styles/globals.css";

export const metadata: Metadata = {
  title: "Atelier — AI Virtual Try-On",
  description: "Drag garments onto an avatar and generate a photoreal outfit render.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
