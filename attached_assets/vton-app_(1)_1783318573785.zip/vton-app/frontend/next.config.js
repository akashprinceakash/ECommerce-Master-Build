/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    remotePatterns: [
      { protocol: "http", hostname: "localhost" },
      { protocol: "https", hostname: "**" }, // Replicate/S3 output URLs vary; tighten in production
    ],
  },
};

module.exports = nextConfig;
