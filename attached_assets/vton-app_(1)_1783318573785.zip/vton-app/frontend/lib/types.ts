export type GarmentCategory =
  | "upper_body"
  | "lower_body"
  | "outerwear"
  | "dress"
  | "accessory";

export interface Garment {
  id: string;
  imageUrl: string;
  typeHint: string;
  category?: GarmentCategory;
  tuck?: boolean;
}

export type JobStatus = "queued" | "processing" | "completed" | "failed";

export interface TryOnJob {
  id: string;
  status: JobStatus;
  resultImageUrl?: string;
  error?: string;
}

/** One entry in the undo/redo history: the full garment selection state
 *  plus the resulting outfit image, if generation succeeded. */
export interface OutfitHistoryEntry {
  garments: Garment[];
  resultImageUrl?: string;
  timestamp: number;
}
