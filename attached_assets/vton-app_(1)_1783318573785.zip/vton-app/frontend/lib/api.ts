import { Garment, TryOnJob } from "./types";

const API_BASE = process.env.NEXT_PUBLIC_API_BASE_URL ?? "http://localhost:4000";

export async function uploadImage(file: File): Promise<string> {
  const form = new FormData();
  form.append("file", file);
  const res = await fetch(`${API_BASE}/api/tryon/upload`, { method: "POST", body: form });
  if (!res.ok) throw new Error(`Upload failed: ${res.status}`);
  const data = await res.json();
  return data.url as string;
}

export async function submitTryOn(avatarImageUrl: string, garments: Garment[]): Promise<string> {
  const res = await fetch(`${API_BASE}/api/tryon`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      avatarImageUrl,
      garments: garments.map((g) => ({
        id: g.id,
        imageUrl: g.imageUrl,
        typeHint: g.typeHint,
        category: g.category,
        tuck: g.tuck,
      })),
      allowCache: true,
    }),
  });
  if (!res.ok) throw new Error(`Try-on submission failed: ${res.status}`);
  const data = await res.json();
  return data.jobId as string;
}

export async function pollTryOnJob(jobId: string): Promise<TryOnJob> {
  const res = await fetch(`${API_BASE}/api/tryon/${jobId}`);
  if (!res.ok) throw new Error(`Job poll failed: ${res.status}`);
  return res.json();
}

/** Polls a job until it completes or fails, calling onTick with each update. */
export async function waitForTryOn(
  jobId: string,
  onTick: (job: TryOnJob) => void,
  intervalMs = 2000,
  timeoutMs = 180_000
): Promise<TryOnJob> {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const job = await pollTryOnJob(jobId);
    onTick(job);
    if (job.status === "completed" || job.status === "failed") return job;
    await new Promise((r) => setTimeout(r, intervalMs));
  }
  throw new Error("Timed out waiting for outfit generation");
}
