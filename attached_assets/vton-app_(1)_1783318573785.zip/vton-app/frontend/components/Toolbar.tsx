"use client";

interface Props {
  onGenerate: () => void;
  onUndo: () => void;
  onRedo: () => void;
  canUndo: boolean;
  canRedo: boolean;
  canGenerate: boolean;
  generating: boolean;
}

export default function Toolbar({
  onGenerate,
  onUndo,
  onRedo,
  canUndo,
  canRedo,
  canGenerate,
  generating,
}: Props) {
  return (
    <div className="toolbar">
      <button className="btn" onClick={onUndo} disabled={!canUndo}>
        ↶ Undo
      </button>
      <button className="btn" onClick={onRedo} disabled={!canRedo}>
        ↷ Redo
      </button>
      <button className="btn primary" onClick={onGenerate} disabled={!canGenerate || generating}>
        {generating ? "Generating…" : "Generate Outfit"}
      </button>
    </div>
  );
}
