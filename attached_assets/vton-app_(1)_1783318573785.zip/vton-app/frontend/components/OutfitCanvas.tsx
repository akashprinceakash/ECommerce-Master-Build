"use client";

import { JobStatus } from "@/lib/types";

interface Props {
  displayImageUrl: string | null;
  status: JobStatus | "idle";
  error?: string;
}

const STATUS_LABEL: Record<string, string> = {
  idle: "",
  queued: "Queued…",
  processing: "Rendering outfit…",
  completed: "",
  failed: "Generation failed",
};

export default function OutfitCanvas({ displayImageUrl, status, error }: Props) {
  const busy = status === "queued" || status === "processing";

  return (
    <div className="panel canvas-panel">
      <h2 style={{ alignSelf: "flex-start" }}>Preview</h2>
      <div className="canvas-frame">
        {displayImageUrl ? (
          <img src={displayImageUrl} alt="Outfit preview" />
        ) : (
          <div className="canvas-placeholder">
            Select an avatar and drag in a garment to see it rendered here.
          </div>
        )}
        {busy && <div className="canvas-overlay">{STATUS_LABEL[status]}</div>}
      </div>
      {status === "failed" && error && (
        <div className="warning-banner" style={{ marginTop: 16 }}>{error}</div>
      )}
    </div>
  );
}
