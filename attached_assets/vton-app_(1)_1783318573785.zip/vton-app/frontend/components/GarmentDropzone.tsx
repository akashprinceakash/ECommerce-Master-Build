"use client";

import { useCallback, useState } from "react";
import { uploadImage } from "@/lib/api";
import { Garment } from "@/lib/types";

interface Props {
  garments: Garment[];
  onAdd: (garment: Garment) => void;
  onRemove: (id: string) => void;
}

/** Infers a human-readable type hint from the uploaded filename, e.g.
 *  "navy-polo-shirt.png" -> "polo shirt". This is only a starting hint —
 *  the backend re-validates/classifies from this string on submit. */
function hintFromFilename(name: string): string {
  return name
    .replace(/\.[^/.]+$/, "")
    .replace(/[-_]+/g, " ")
    .trim();
}

export default function GarmentDropzone({ garments, onAdd, onRemove }: Props) {
  const [dragOver, setDragOver] = useState(false);
  const [uploading, setUploading] = useState(false);

  const handleFiles = useCallback(
    async (files: FileList | null) => {
      if (!files || files.length === 0) return;
      setUploading(true);
      try {
        for (const file of Array.from(files)) {
          const url = await uploadImage(file);
          onAdd({
            id: crypto.randomUUID(),
            imageUrl: url,
            typeHint: hintFromFilename(file.name),
          });
        }
      } finally {
        setUploading(false);
      }
    },
    [onAdd]
  );

  return (
    <div className="panel">
      <h2>Garments</h2>
      <div
        className={`dropzone${dragOver ? " dragover" : ""}`}
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragOver(false);
          handleFiles(e.dataTransfer.files);
        }}
        onClick={() => document.getElementById("garment-file-input")?.click()}
      >
        {uploading ? "Uploading…" : "Drag garments here, or click to browse"}
        <input
          id="garment-file-input"
          type="file"
          accept="image/*"
          multiple
          hidden
          onChange={(e) => handleFiles(e.target.files)}
        />
      </div>

      <div className="garment-list">
        {garments.map((g) => (
          <div className="garment-chip" key={g.id}>
            <img src={g.imageUrl} alt={g.typeHint} />
            <div className="meta">
              <span className="label">{g.typeHint || "Untitled garment"}</span>
              <span className="category">{g.category ?? "auto-detecting…"}</span>
            </div>
            <button className="icon-btn" onClick={() => onRemove(g.id)} title="Remove garment">
              ✕
            </button>
          </div>
        ))}
        {garments.length === 0 && (
          <p style={{ fontSize: 12, color: "#8b8272" }}>
            No garments yet — add a polo, jeans, a jacket, anything.
          </p>
        )}
      </div>
    </div>
  );
}
