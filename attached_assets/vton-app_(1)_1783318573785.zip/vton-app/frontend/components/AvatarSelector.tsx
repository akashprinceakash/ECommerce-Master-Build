"use client";

import { uploadImage } from "@/lib/api";

interface Props {
  avatars: string[];
  selected: string | null;
  onSelect: (url: string) => void;
  onUpload: (url: string) => void;
}

export default function AvatarSelector({ avatars, selected, onSelect, onUpload }: Props) {
  return (
    <div className="panel">
      <h2>Avatar</h2>
      <div className="avatar-options">
        {avatars.map((url) => (
          <div
            key={url}
            className={`avatar-thumb${selected === url ? " selected" : ""}`}
            onClick={() => onSelect(url)}
          >
            <img src={url} alt="avatar option" />
          </div>
        ))}
        <div
          className="avatar-thumb"
          style={{ display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20, color: "#8b8272" }}
          onClick={() => document.getElementById("avatar-file-input")?.click()}
          title="Upload your own avatar"
        >
          +
          <input
            id="avatar-file-input"
            type="file"
            accept="image/*"
            hidden
            onChange={async (e) => {
              const file = e.target.files?.[0];
              if (!file) return;
              const url = await uploadImage(file);
              onUpload(url);
            }}
          />
        </div>
      </div>
    </div>
  );
}
