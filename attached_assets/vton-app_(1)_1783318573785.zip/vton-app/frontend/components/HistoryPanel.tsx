"use client";

import { OutfitHistoryEntry } from "@/lib/types";

interface Props {
  history: OutfitHistoryEntry[];
  activeIndex: number;
  onSelect: (index: number) => void;
}

export default function HistoryPanel({ history, activeIndex, onSelect }: Props) {
  return (
    <div className="panel">
      <h2>History</h2>
      <div className="history-list">
        {history.length === 0 && (
          <p style={{ fontSize: 12, color: "#8b8272" }}>
            Generated outfits will appear here so you can jump back to any version.
          </p>
        )}
        {history
          .map((entry, i) => ({ entry, i }))
          .slice()
          .reverse()
          .map(({ entry, i }) => (
            <div
              key={entry.timestamp}
              className={`history-item${i === activeIndex ? " active" : ""}`}
              onClick={() => onSelect(i)}
            >
              {entry.resultImageUrl ? (
                <img src={entry.resultImageUrl} alt={`Outfit v${i + 1}`} />
              ) : (
                <div style={{ width: 44, height: 56, background: "#29251f", borderRadius: 1 }} />
              )}
              <div>
                <div style={{ fontSize: 12 }}>Outfit v{i + 1}</div>
                <div className="ts">
                  {new Date(entry.timestamp).toLocaleTimeString()} · {entry.garments.length} item
                  {entry.garments.length === 1 ? "" : "s"}
                </div>
              </div>
            </div>
          ))}
      </div>
    </div>
  );
}
