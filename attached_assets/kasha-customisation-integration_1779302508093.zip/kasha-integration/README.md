# KA.SHA Customisation Studio — Integration Guide

## What This Bundle Adds

| File | Purpose |
|------|---------|
| `frontend/pages/customize.tsx` | **4-Step customer wizard** (Style → Parts → Logo → Size) |
| `frontend/pages/admin-product-new.tsx` | **Admin product upload** page — fabric / pattern / print type |
| `frontend/components/3d/patterns.ts` | Updated — `ProductType`, `kasha-gt015` entry, GT015 source colour constants |
| `frontend/components/3d/gt-styles.ts` | Unchanged — pixel-swap engine and GT001–GT032 base64 textures |
| `backend/schema/products.ts` | Updated — `category` column drives UI flow |
| `backend/routes/products.ts` | Updated — file upload endpoints + GT pattern enforcement |

---

## Product Types

### fabric — Full Editor
Admin sets `category = "fabric"`.  
Customer: Solid colours + Print library + GT pattern picker + logo + per-zone colours.

### pattern — GT Style Locked (e.g. GT015)
Admin sets `category = "pattern"` and picks a GT style.  
Name is auto-suffixed `[gt:GT015]`. `customize.tsx` auto-applies the locked pattern.  
Customer: Only Color A / Color B swatches. No prints.  
**GT015 pixel-swap**: Color A (black #000000) ↔ any hex. Color B (pink #F0CED2) ↔ any hex.

### print — Print Only
Admin sets `category = "print"`.  
Customer: Picks from the Print library. No colour controls.

---

## GT015 Pixel-Swap Algorithm

`applyGtStyle(fc, style, { primary, accent })` in `gt-styles.ts`:
1. Loads the embedded 1024×1024 base64 PNG for GT015
2. Draws it to an offscreen canvas
3. Walks every pixel — if distance to `#000000` < 60 → replaces with `primary`; if distance to `#F0CED2` < 60 → replaces with `accent`
4. Puts the recoloured PNG as a FabricImage on the Fabric canvas
5. `syncTexture()` bakes Fabric → model-viewer GLB material

Same algorithm as the standalone GT015 colour customizer HTML provided by the customer.

---

## Wiring

### Replace files
```
frontend/pages/customize.tsx
frontend/pages/admin-product-new.tsx
frontend/components/3d/patterns.ts
backend/schema/products.ts
backend/routes/products.ts
```

### Router (App.tsx)
```tsx
<Route path="/admin/products/new" component={AdminProductNew} />
```

### API server (routes/index.ts)
```ts
import { productRouter } from "./products";
app.use("/api", productRouter);
```

### kasha.png
```
cp kasha.png frontend/public/patterns/kasha.png
```

### 3D model
```
cp collar_t-shirt_model.glb frontend/public/models/collar_t-shirt_model.glb
```
Set `modelUrl = "/models/collar_t-shirt_model.glb"` on the product record.

### DB migration
```bash
pnpm --filter @workspace/db drizzle-kit push
```

### Install multer
```bash
pnpm add multer @types/multer
```

---

## Customer Flow

```
/products/:id
  "Customise This Product"
         ↓
/customize/:id  (4-step wizard)
  Step 1  Style    → colour / print / pattern
  Step 2  Parts    → per-zone colour overrides
  Step 3  Logo     → optional upload + positioning
  Step 4  Size     → size + qty + add to cart
```

## Admin Flow

```
/admin/products/new
  Select type: fabric | pattern | print
  If pattern → pick GT style → name auto-suffixed [gt:GTxxx]
  Upload 3D model + thumbnail
  "Publish Product"
```
