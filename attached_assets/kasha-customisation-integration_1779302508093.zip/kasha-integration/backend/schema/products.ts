/**
 * schema/products.ts — Drizzle ORM table for KA.SHA products
 *
 * Key change: `category` column now drives UI behaviour:
 *   "fabric"  — full customiser (solid + print + GT patterns)
 *   "pattern" — locked GT style; customer only swaps Color A / B
 *   "print"   — print-only; no colour controls
 *
 * When admin creates a "pattern" product, the product name is saved as:
 *   "Collar Polo GT015 [gt:GT015]"
 * The customize.tsx page parses the "[gt:GTxxx]" suffix to auto-apply the
 * locked style on page load.
 */

import { pgTable, serial, text, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// ── Products table ────────────────────────────────────────────────────────────
export const products = pgTable("products", {
  id:           serial("id").primaryKey(),

  // Human-readable name. For pattern products includes "[gt:GTxxx]" suffix.
  name:         text("name").notNull(),
  description:  text("description").notNull().default(""),

  // Controls the customiser UI flow:
  //   "fabric"  → Solid + Print + Pattern editor
  //   "pattern" → GT style locked; Color A/B swaps only
  //   "print"   → Print selection only; no colour changes
  category:     text("category").notNull().default("fabric"),

  // Price in smallest currency unit (paise for INR)
  priceInPaise: integer("price_in_paise").notNull().default(0),

  // 3D model: served from /public/models/ or uploaded via /api/upload/model
  modelUrl:     text("model_url"),

  // Product listing thumbnail image
  thumbnailUrl: text("thumbnail_url"),

  // Default body colour (hex). For pattern products = GT primary color.
  defaultColor: text("default_color").default("#FFFFFF"),

  // Whether this product appears in the storefront
  isPublished:  boolean("is_published").notNull().default(false),

  createdAt:    timestamp("created_at").defaultNow(),
  updatedAt:    timestamp("updated_at").defaultNow(),
});

// ── Zod insert schema ─────────────────────────────────────────────────────────
export const insertProductSchema = createInsertSchema(products, {
  name:         z.string().min(1).max(200),
  description:  z.string().max(2000).default(""),
  category:     z.enum(["fabric", "pattern", "print"]).default("fabric"),
  priceInPaise: z.number().int().min(0),
  modelUrl:     z.string().url().optional().nullable(),
  thumbnailUrl: z.string().url().optional().nullable(),
  defaultColor: z.string().regex(/^#[0-9a-fA-F]{6}$/).default("#FFFFFF"),
  isPublished:  z.boolean().default(false),
}).omit({ id: true, createdAt: true, updatedAt: true });

export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product       = typeof products.$inferSelect;
