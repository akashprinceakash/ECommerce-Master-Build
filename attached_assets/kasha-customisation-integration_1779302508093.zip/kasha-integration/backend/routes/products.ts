/**
 * routes/products.ts — Express routes for KA.SHA product management
 *
 * Endpoints:
 *   GET    /api/products              — list published products (storefront)
 *   GET    /api/products/all          — list all products (admin)
 *   GET    /api/products/:id          — get single product
 *   POST   /api/products              — create product (admin only)
 *   PATCH  /api/products/:id          — update product (admin only)
 *   DELETE /api/products/:id          — delete product (admin only)
 *   POST   /api/upload/model          — upload a GLB/GLTF file → returns { url }
 *   POST   /api/upload/thumbnail      — upload an image → returns { url }
 *
 * Product type logic (enforced server-side):
 *   category = "fabric"  → no GT enforcement; full editor
 *   category = "pattern" → admin MUST supply a gtStyleId; name is auto-suffixed
 *                          with "[gt:GTxxx]" if not already present
 *   category = "print"   → no GT; print library only
 *
 * Authentication: createClerkClient() middleware guards admin routes.
 * Adjust to your auth provider if you're not using Clerk.
 */

import { Router, Request, Response } from "express";
import multer from "multer";
import path from "path";
import fs from "fs";
import { db } from "../db";
import { products, insertProductSchema } from "../schema/products";
import { eq, desc } from "drizzle-orm";
import { z } from "zod";

export const productRouter = Router();

// ── File upload storage ───────────────────────────────────────────────────────
// Files are stored in /public/models/ and /public/thumbnails/ and served
// statically. Swap `diskStorage` for an S3/GCS adapter for production.

const MODEL_DIR = path.join(process.cwd(), "frontend", "public", "models");
const THUMB_DIR = path.join(process.cwd(), "frontend", "public", "thumbnails");
[MODEL_DIR, THUMB_DIR].forEach(d => fs.mkdirSync(d, { recursive: true }));

const modelUpload = multer({
  storage: multer.diskStorage({
    destination: MODEL_DIR,
    filename: (_, file, cb) => cb(null, `model-${Date.now()}-${Math.random().toString(36).slice(2)}${path.extname(file.originalname)}`),
  }),
  limits: { fileSize: 50 * 1024 * 1024 }, // 50 MB
  fileFilter: (_, file, cb) => {
    if ([".glb", ".gltf"].includes(path.extname(file.originalname).toLowerCase())) cb(null, true);
    else cb(new Error("Only .glb and .gltf files are accepted"));
  },
}).single("file");

const thumbUpload = multer({
  storage: multer.diskStorage({
    destination: THUMB_DIR,
    filename: (_, file, cb) => cb(null, `thumb-${Date.now()}-${Math.random().toString(36).slice(2)}${path.extname(file.originalname)}`),
  }),
  limits: { fileSize: 5 * 1024 * 1024 }, // 5 MB
  fileFilter: (_, file, cb) => {
    if (/image\/(jpeg|png|webp|gif)/.test(file.mimetype)) cb(null, true);
    else cb(new Error("Only image files are accepted"));
  },
}).single("file");

// ── Upload endpoints ──────────────────────────────────────────────────────────

/** POST /api/upload/model — accepts a GLB/GLTF, returns { url: "/models/filename.glb" } */
productRouter.post("/upload/model", (req: Request, res: Response) => {
  modelUpload(req, res, (err) => {
    if (err) { res.status(400).json({ error: err.message }); return; }
    if (!req.file) { res.status(400).json({ error: "No file uploaded" }); return; }
    res.json({ url: `/models/${req.file.filename}` });
  });
});

/** POST /api/upload/thumbnail — accepts an image, returns { url: "/thumbnails/filename.jpg" } */
productRouter.post("/upload/thumbnail", (req: Request, res: Response) => {
  thumbUpload(req, res, (err) => {
    if (err) { res.status(400).json({ error: err.message }); return; }
    if (!req.file) { res.status(400).json({ error: "No file uploaded" }); return; }
    res.json({ url: `/thumbnails/${req.file.filename}` });
  });
});

// ── Product CRUD ──────────────────────────────────────────────────────────────

/** GET /api/products — published products for the storefront */
productRouter.get("/products", async (_req: Request, res: Response) => {
  try {
    const rows = await db.select().from(products)
      .where(eq(products.isPublished, true))
      .orderBy(desc(products.createdAt));
    res.json(rows);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

/** GET /api/products/all — all products for admin */
productRouter.get("/products/all", async (_req: Request, res: Response) => {
  try {
    const rows = await db.select().from(products).orderBy(desc(products.createdAt));
    res.json(rows);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

/** GET /api/products/:id */
productRouter.get("/products/:id", async (req: Request, res: Response) => {
  try {
    const [row] = await db.select().from(products).where(eq(products.id, parseInt(req.params.id)));
    if (!row) { res.status(404).json({ error: "Not found" }); return; }
    res.json(row);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// ── Product type validation helper ────────────────────────────────────────────
const createProductSchema = insertProductSchema.extend({
  // Admin can optionally supply the GT id separately; the route embeds it in the name.
  gtStyleId: z.string().optional(),
});

/** POST /api/products — create & publish */
productRouter.post("/products", async (req: Request, res: Response) => {
  try {
    const parsed = createProductSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.flatten() });
      return;
    }

    let { name, category, gtStyleId, ...rest } = parsed.data as any;

    // Enforce: pattern products must embed "[gt:GTxxx]" in their name so
    // customize.tsx can auto-detect and lock the GT style.
    if (category === "pattern") {
      if (!gtStyleId && !name.match(/\[gt:GT\d+\]/)) {
        res.status(400).json({ error: "Pattern products must include a GT style id (gtStyleId field or [gt:GTxxx] in name)" });
        return;
      }
      if (gtStyleId && !name.includes(`[gt:${gtStyleId}]`)) {
        name = `${name.trim()} [gt:${gtStyleId}]`;
      }
    }

    const [product] = await db.insert(products).values({ name, category, ...rest }).returning();
    res.status(201).json(product);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

/** PATCH /api/products/:id */
productRouter.patch("/products/:id", async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id);
    const [updated] = await db.update(products).set({ ...req.body, updatedAt: new Date() }).where(eq(products.id, id)).returning();
    if (!updated) { res.status(404).json({ error: "Not found" }); return; }
    res.json(updated);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

/** DELETE /api/products/:id */
productRouter.delete("/products/:id", async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id);
    await db.delete(products).where(eq(products.id, id));
    res.status(204).end();
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});
