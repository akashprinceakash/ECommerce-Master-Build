/**
 * admin/products/new.tsx — KA.SHA Admin: Upload & Publish a Product
 *
 * Three product types the admin can publish:
 *
 *  1. "fabric"  — Solid-colour polo / tee.
 *                 Customer sees: Solids + Prints + Patterns tabs. Full editor.
 *                 Admin inputs: name, price, 3D model, thumbnail.
 *                 No locked GT style required.
 *
 *  2. "pattern" — Polo with a pre-applied GT pattern (e.g. GT015 "Black & Blush").
 *                 Customer sees: Pattern tab locked. Can only swap Color A / Color B.
 *                 Admin inputs: name, price, 3D model, thumbnail, GT style selection.
 *                 Name is auto-suffixed with "[gt:GTxxx]" for detection in customize.tsx.
 *
 *  3. "print"   — Pre-printed T-shirt (paisley, graffiti, etc.).
 *                 Customer sees: Print tab, can select prints ONLY. No colour controls.
 *                 Admin inputs: name, price, 3D model, thumbnail.
 *                 Category stored as "print" in the DB.
 */

import { useState, useRef } from "react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { getApiUrl } from "@/lib/api";
import { GT_STYLES, type GtStyleDef } from "@/components/3d/gt-styles";

// ── Theme ─────────────────────────────────────────────────────────────────────
const V = {
  bg: "#0e0c0a", sf: "rgba(255,255,255,0.04)", sf2: "rgba(255,255,255,0.08)",
  bd: "rgba(255,255,255,0.09)", bd2: "rgba(255,255,255,0.15)",
  tx: "#f0ece4", mu: "#7a7470", ac: "#c9a87c",
};

const GT_GROUPS = [
  { id: "classic",    label: "Classic"     },
  { id: "sport-side", label: "Sport Side"  },
  { id: "wave",       label: "Wave Panel"  },
  { id: "hourglass",  label: "Hourglass"   },
  { id: "pinstripe",  label: "Pinstripe"   },
  { id: "raglan",     label: "Raglan"      },
] as const;

// ── Auth helper ───────────────────────────────────────────────────────────────
async function getToken(): Promise<string | null> {
  try { const c = (window as any).Clerk; return c?.session ? await c.session.getToken() : null; }
  catch { return null; }
}
async function apiFetch(path: string, opts?: RequestInit): Promise<any> {
  const token = await getToken();
  const headers: Record<string, string> = {};
  if (!(opts?.body instanceof FormData)) headers["Content-Type"] = "application/json";
  if (token) headers["Authorization"] = `Bearer ${token}`;
  const res = await fetch(`${getApiUrl()}${path}`, { ...opts, headers });
  if (!res.ok) throw new Error(await res.text());
  return res.status === 204 ? null : res.json();
}

type ProductType = "fabric" | "pattern" | "print";

export default function AdminProductNew() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  // ── Form state ────────────────────────────────────────────────────────────
  const [productType, setProductType] = useState<ProductType>("fabric");
  const [name, setName]               = useState("");
  const [description, setDescription] = useState("");
  const [priceInPaise, setPrice]       = useState("");
  const [selectedGt, setSelectedGt]   = useState<GtStyleDef | null>(null);
  const [gtGroupOpen, setGtGroupOpen] = useState<string | null>("hourglass");

  // File uploads
  const modelFileRef    = useRef<HTMLInputElement>(null);
  const thumbFileRef    = useRef<HTMLInputElement>(null);
  const [modelFileName, setModelFileName]   = useState("");
  const [thumbFileName, setThumbFileName]   = useState("");
  const [uploadProgress, setUploadProgress] = useState(0);

  // ── Upload model/thumbnail to server and get back URLs ────────────────────
  async function uploadFile(file: File, endpoint: string): Promise<string> {
    const form = new FormData();
    form.append("file", file);
    const token = await getToken();
    const res = await fetch(`${getApiUrl()}${endpoint}`, {
      method: "POST",
      headers: token ? { Authorization: `Bearer ${token}` } : {},
      body: form,
    });
    if (!res.ok) throw new Error(await res.text());
    const data = await res.json();
    return data.url as string;
  }

  // ── Create product mutation ───────────────────────────────────────────────
  const createMut = useMutation({
    mutationFn: async () => {
      if (!name.trim()) throw new Error("Product name is required");
      if (!priceInPaise || isNaN(Number(priceInPaise))) throw new Error("Enter a valid price");
      if (productType === "pattern" && !selectedGt) throw new Error("Select a GT Design Style for pattern products");

      setUploadProgress(10);

      // Upload 3D model
      let modelUrl = "";
      const modelFile = modelFileRef.current?.files?.[0];
      if (modelFile) {
        modelUrl = await uploadFile(modelFile, "/api/upload/model");
        setUploadProgress(50);
      }

      // Upload thumbnail
      let thumbnailUrl = "";
      const thumbFile = thumbFileRef.current?.files?.[0];
      if (thumbFile) {
        thumbnailUrl = await uploadFile(thumbFile, "/api/upload/thumbnail");
        setUploadProgress(80);
      }

      // Build final product name
      // For pattern products, embed the GT id so customize.tsx can auto-detect it
      const finalName = productType === "pattern" && selectedGt
        ? `${name.trim()} [gt:${selectedGt.id}]`
        : name.trim();

      const payload = {
        name:         finalName,
        description:  description.trim(),
        category:     productType,          // "fabric" | "pattern" | "print"
        priceInPaise: parseInt(priceInPaise, 10),
        modelUrl:     modelUrl || null,
        thumbnailUrl: thumbnailUrl || null,
        defaultColor: productType === "pattern" && selectedGt
          ? selectedGt.defaultColors.primary
          : "#FFFFFF",
        isPublished:  true,
      };

      const product = await apiFetch("/api/products", { method: "POST", body: JSON.stringify(payload) });
      setUploadProgress(100);
      return product;
    },
    onSuccess: (product) => {
      toast({ title: "Product published ✓", description: `"${product.name}" is now live in the store.` });
      setTimeout(() => setLocation(`/products/${product.id}`), 800);
    },
    onError: (e: any) => {
      setUploadProgress(0);
      toast({ title: "Error", description: e.message, variant: "destructive" });
    },
  });

  // ── Shared styles ─────────────────────────────────────────────────────────
  const inp: React.CSSProperties = {
    width: "100%", padding: "9px 11px",
    background: "rgba(0,0,0,.35)", border: `1px solid ${V.bd}`,
    borderRadius: 8, color: V.tx, fontFamily: "inherit",
    fontSize: 13, outline: "none", boxSizing: "border-box",
  };
  const sl: React.CSSProperties = {
    fontSize: 10, letterSpacing: ".1em", textTransform: "uppercase",
    color: V.mu, fontWeight: 600, marginBottom: 6,
  };
  const section: React.CSSProperties = {
    background: V.sf, border: `1px solid ${V.bd}`,
    borderRadius: 10, padding: "14px 16px", marginBottom: 14,
  };

  return (
    <div style={{ minHeight: "100vh", background: V.bg, color: V.tx, fontFamily: "'DM Sans',sans-serif" }}>

      {/* Header */}
      <header style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 24px", height: 48, borderBottom: `1px solid ${V.bd}`, background: "rgba(8,6,4,.9)", backdropFilter: "blur(12px)", position: "sticky", top: 0, zIndex: 50 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <a href="/admin/products" style={{ color: V.mu, fontSize: 13, textDecoration: "none" }}>← Admin</a>
          <div style={{ width: 1, height: 16, background: V.bd }} />
          <span style={{ fontFamily: "'Playfair Display',serif", fontSize: 15, color: V.ac }}>Add New Product</span>
        </div>
        <button onClick={() => createMut.mutate()} disabled={createMut.isPending}
          style={{ padding: "7px 18px", borderRadius: 9, border: "none", background: V.ac, color: V.bg, fontSize: 12, fontWeight: 700, cursor: "pointer", opacity: createMut.isPending ? .6 : 1 }}>
          {createMut.isPending ? `Uploading ${uploadProgress}%…` : "Publish Product"}
        </button>
      </header>

      <div style={{ maxWidth: 720, margin: "0 auto", padding: "28px 20px" }}>

        {/* Progress bar */}
        {createMut.isPending && (
          <div style={{ height: 3, background: V.bd, borderRadius: 2, marginBottom: 20, overflow: "hidden" }}>
            <div style={{ height: "100%", background: V.ac, width: `${uploadProgress}%`, transition: "width .4s" }} />
          </div>
        )}

        {/* ── Product Type ────────────────────────────────────────────────── */}
        <div style={section}>
          <div style={sl}>Product Type</div>
          <p style={{ fontSize: 11, color: V.mu, marginBottom: 12, lineHeight: 1.6 }}>
            This controls what the customer can customise. Choose carefully — it cannot be changed after publishing.
          </p>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {([
              { type: "fabric"  as const, label: "Fabric (Solid / Customisable)", desc: "Customer picks colour, prints, patterns, adds text & logo. Full editor." },
              { type: "pattern" as const, label: "Pattern (GT Style Locked)",      desc: "Customer sees a fixed GT pattern. Can only swap Color A & Color B — no prints." },
              { type: "print"   as const, label: "Print (Pre-Printed / Image)",     desc: "Customer picks from the print library. No colour changes allowed." },
            ] as const).map(({ type, label, desc }) => (
              <div key={type} onClick={() => setProductType(type)} style={{
                display: "flex", alignItems: "flex-start", gap: 12, padding: "11px 13px",
                borderRadius: 9, border: `1px solid ${productType === type ? V.ac : V.bd}`,
                background: productType === type ? "rgba(201,168,124,.09)" : V.sf,
                cursor: "pointer", transition: "all .15s",
              }}>
                <div style={{ width: 18, height: 18, borderRadius: "50%", border: `2px solid ${productType === type ? V.ac : V.bd2}`, background: productType === type ? V.ac : "transparent", flexShrink: 0, marginTop: 1 }} />
                <div>
                  <div style={{ fontSize: 13, fontWeight: 600, color: productType === type ? V.ac : V.tx }}>{label}</div>
                  <div style={{ fontSize: 11, color: V.mu, marginTop: 2, lineHeight: 1.5 }}>{desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* ── Basic info ──────────────────────────────────────────────────── */}
        <div style={section}>
          <div style={sl}>Product Info</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            <div>
              <div style={{ fontSize: 11, color: V.mu, marginBottom: 4 }}>Product Name *</div>
              <input value={name} onChange={e => setName(e.target.value)} placeholder='e.g. "Classic Polo GT015"'
                style={inp} />
              {productType === "pattern" && selectedGt && (
                <div style={{ fontSize: 10, color: V.mu, marginTop: 4 }}>
                  Will be saved as: <strong style={{ color: V.ac }}>{name.trim() || "…"} [{selectedGt.id}]</strong>
                </div>
              )}
            </div>
            <div>
              <div style={{ fontSize: 11, color: V.mu, marginBottom: 4 }}>Description</div>
              <textarea value={description} onChange={e => setDescription(e.target.value)}
                rows={3} placeholder="Describe the product for customers…"
                style={{ ...inp, resize: "vertical" }} />
            </div>
            <div>
              <div style={{ fontSize: 11, color: V.mu, marginBottom: 4 }}>Price (₹, in paise) *</div>
              <input value={priceInPaise} onChange={e => setPrice(e.target.value)}
                type="number" placeholder="e.g. 299900 = ₹2,999"
                style={inp} />
              {priceInPaise && !isNaN(Number(priceInPaise)) && (
                <div style={{ fontSize: 10, color: V.mu, marginTop: 3 }}>
                  = ₹{(Number(priceInPaise) / 100).toLocaleString("en-IN")}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* ── GT Style selection (pattern only) ───────────────────────────── */}
        {productType === "pattern" && (
          <div style={section}>
            <div style={sl}>GT Design Style *</div>
            <p style={{ fontSize: 11, color: V.mu, marginBottom: 12, lineHeight: 1.6 }}>
              Select the GT pattern to lock this product to. The customer will be able to change Color A and Color B using pixel-swap recoloring, but cannot switch patterns.
            </p>

            {selectedGt && (
              <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 12px", background: "rgba(201,168,124,.08)", border: `1px solid ${V.ac}`, borderRadius: 9, marginBottom: 12 }}>
                <div style={{ width: 36, height: 36, borderRadius: 7, background: `linear-gradient(135deg,${selectedGt.defaultColors.primary} 50%,${selectedGt.defaultColors.accent} 50%)`, border: `1px solid ${V.bd}`, flexShrink: 0 }} />
                <div>
                  <div style={{ fontSize: 13, fontWeight: 600, color: V.ac }}>{selectedGt.id} — {selectedGt.label}</div>
                  <div style={{ fontSize: 10, color: V.mu, marginTop: 2 }}>
                    Primary: {selectedGt.defaultColors.primary} · Accent: {selectedGt.defaultColors.accent}
                    {selectedGt.defaultColors.tertiary ? ` · Third: ${selectedGt.defaultColors.tertiary}` : ""}
                  </div>
                </div>
                <button onClick={() => setSelectedGt(null)} style={{ marginLeft: "auto", background: "none", border: "none", color: V.mu, cursor: "pointer", fontSize: 14 }}>×</button>
              </div>
            )}

            {GT_GROUPS.map(group => {
              const groupStyles = GT_STYLES.filter(s => s.group === group.id);
              const isOpen = gtGroupOpen === group.id;
              return (
                <div key={group.id} style={{ border: `1px solid ${V.bd}`, borderRadius: 8, overflow: "hidden", marginBottom: 6 }}>
                  <button onClick={() => setGtGroupOpen(isOpen ? null : group.id)} style={{
                    width: "100%", display: "flex", alignItems: "center", justifyContent: "space-between",
                    padding: "8px 12px", background: isOpen ? "rgba(201,168,124,.08)" : V.sf,
                    border: "none", cursor: "pointer", fontFamily: "inherit",
                    color: isOpen ? V.ac : V.mu, fontWeight: 600, fontSize: 11,
                  }}>
                    <span>{group.label} <span style={{ opacity: .5, fontWeight: 400 }}>({groupStyles.length})</span></span>
                    <span style={{ fontSize: 9 }}>{isOpen ? "▲" : "▼"}</span>
                  </button>
                  {isOpen && (
                    <div style={{ display: "grid", gridTemplateColumns: "repeat(5,1fr)", gap: 5, padding: "8px 10px", background: V.sf }}>
                      {groupStyles.map(style => {
                        const isActive = selectedGt?.id === style.id;
                        return (
                          <button key={style.id} onClick={() => setSelectedGt(style)} title={`${style.id} — ${style.label}`}
                            style={{ padding: "6px 4px", borderRadius: 7, border: isActive ? `2px solid ${V.ac}` : `1px solid ${V.bd}`, background: isActive ? "rgba(201,168,124,.12)" : "transparent", cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", gap: 3 }}>
                            {/* Mini colour preview */}
                            <div style={{ width: 32, height: 20, borderRadius: 4, background: `linear-gradient(90deg,${style.defaultColors.primary} 55%,${style.defaultColors.accent} 55%)`, border: `1px solid ${V.bd}` }} />
                            <span style={{ fontSize: 8, color: isActive ? V.ac : V.mu, fontWeight: 600, letterSpacing: ".04em" }}>{style.id}</span>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* ── 3D Model upload ─────────────────────────────────────────────── */}
        <div style={section}>
          <div style={sl}>3D Model (GLB / GLTF)</div>
          <p style={{ fontSize: 11, color: V.mu, marginBottom: 10, lineHeight: 1.6 }}>
            Upload the collar t-shirt GLB. The model must have a UV-mapped baseColorTexture slot for the design to appear on the 3D mesh.
            The <code style={{ background: "rgba(255,255,255,.07)", padding: "1px 4px", borderRadius: 3, fontSize: 10 }}>collar_t-shirt_model.glb</code> you provided is already included in the project's <code style={{ background: "rgba(255,255,255,.07)", padding: "1px 4px", borderRadius: 3, fontSize: 10 }}>/public/models/</code> folder and can be referenced directly.
          </p>
          <label style={{ display: "block", border: `1.5px dashed ${V.bd2}`, borderRadius: 9, padding: 16, textAlign: "center", cursor: "pointer", transition: "all .15s" }}
            onMouseEnter={e => (e.currentTarget.style.borderColor = V.ac)} onMouseLeave={e => (e.currentTarget.style.borderColor = V.bd2)}>
            <div style={{ fontSize: 22, marginBottom: 4 }}>🗂</div>
            <div style={{ fontSize: 11, color: V.mu }}>
              {modelFileName ? <strong style={{ color: V.tx }}>{modelFileName}</strong> : <><strong style={{ color: V.ac }}>Click to upload</strong> or drag & drop</>}
            </div>
            <div style={{ fontSize: 10, color: V.mu, marginTop: 2 }}>.glb or .gltf — max 50 MB</div>
            <input ref={modelFileRef} type="file" accept=".glb,.gltf" style={{ display: "none" }}
              onChange={e => setModelFileName(e.target.files?.[0]?.name || "")} />
          </label>
          <div style={{ marginTop: 8, fontSize: 10, color: V.mu }}>
            Or enter a URL directly:
            <input placeholder="https://…/model.glb" style={{ ...inp, marginTop: 4, fontSize: 11 }} />
          </div>
        </div>

        {/* ── Thumbnail upload ────────────────────────────────────────────── */}
        <div style={section}>
          <div style={sl}>Product Thumbnail</div>
          <label style={{ display: "block", border: `1.5px dashed ${V.bd2}`, borderRadius: 9, padding: 16, textAlign: "center", cursor: "pointer", transition: "all .15s" }}
            onMouseEnter={e => (e.currentTarget.style.borderColor = V.ac)} onMouseLeave={e => (e.currentTarget.style.borderColor = V.bd2)}>
            <div style={{ fontSize: 22, marginBottom: 4 }}>🖼</div>
            <div style={{ fontSize: 11, color: V.mu }}>
              {thumbFileName ? <strong style={{ color: V.tx }}>{thumbFileName}</strong> : <><strong style={{ color: V.ac }}>Click to upload</strong> thumbnail</>}
            </div>
            <div style={{ fontSize: 10, color: V.mu, marginTop: 2 }}>PNG, JPG, WebP — recommended 800×800 px</div>
            <input ref={thumbFileRef} type="file" accept="image/*" style={{ display: "none" }}
              onChange={e => setThumbFileName(e.target.files?.[0]?.name || "")} />
          </label>
        </div>

        {/* ── What the customer will see ──────────────────────────────────── */}
        <div style={{ background: "rgba(201,168,124,.06)", border: `1px solid rgba(201,168,124,.2)`, borderRadius: 10, padding: "14px 16px", marginBottom: 14 }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: V.ac, marginBottom: 8 }}>
            📋 What the customer will see
          </div>
          <ul style={{ paddingLeft: 16, display: "flex", flexDirection: "column", gap: 6 }}>
            {productType === "fabric" && (
              <>
                <li style={{ fontSize: 11, color: V.mu, lineHeight: 1.5 }}>Step 1 — Solid colours, Print library, and GT Pattern picker (all tabs visible)</li>
                <li style={{ fontSize: 11, color: V.mu, lineHeight: 1.5 }}>Step 2 — Per-zone colour overrides (collar, front, back, sleeves)</li>
                <li style={{ fontSize: 11, color: V.mu, lineHeight: 1.5 }}>Step 3 — Optional logo upload with 9-point positioning</li>
                <li style={{ fontSize: 11, color: V.mu, lineHeight: 1.5 }}>Step 4 — Size XS–XXL, quantity, add to cart</li>
              </>
            )}
            {productType === "pattern" && (
              <>
                <li style={{ fontSize: 11, color: V.mu, lineHeight: 1.5 }}>Step 1 — <strong style={{ color: V.tx }}>Pattern tab pre-locked</strong> to {selectedGt?.id || "the selected GT style"}. Customer can only change Color A and Color B via pixel-swap recoloring.</li>
                <li style={{ fontSize: 11, color: V.mu, lineHeight: 1.5 }}>Step 2 — Per-zone colour overrides (applied on top of the GT pattern)</li>
                <li style={{ fontSize: 11, color: V.mu, lineHeight: 1.5 }}>Step 3 — Optional logo upload</li>
                <li style={{ fontSize: 11, color: V.mu, lineHeight: 1.5 }}>Step 4 — Size + cart</li>
              </>
            )}
            {productType === "print" && (
              <>
                <li style={{ fontSize: 11, color: V.mu, lineHeight: 1.5 }}>Step 1 — <strong style={{ color: V.tx }}>Print tab only</strong>. Customer selects a print from the library. No colour controls.</li>
                <li style={{ fontSize: 11, color: V.mu, lineHeight: 1.5 }}>Step 2 — Part colours are <strong style={{ color: V.tx }}>hidden</strong> for print products</li>
                <li style={{ fontSize: 11, color: V.mu, lineHeight: 1.5 }}>Step 3 — Optional logo upload</li>
                <li style={{ fontSize: 11, color: V.mu, lineHeight: 1.5 }}>Step 4 — Size + cart</li>
              </>
            )}
          </ul>
        </div>

        {/* CTA */}
        <button onClick={() => createMut.mutate()} disabled={createMut.isPending}
          style={{ width: "100%", padding: "13px 0", borderRadius: 11, border: "none", background: V.ac, color: V.bg, fontSize: 14, fontWeight: 700, cursor: "pointer", opacity: createMut.isPending ? .6 : 1, letterSpacing: ".03em" }}>
          {createMut.isPending ? `Publishing… ${uploadProgress}%` : "✦ Publish Product"}
        </button>
        <div style={{ height: 40 }} />
      </div>
    </div>
  );
}
